import React from 'react';
import { BookOpen, ArrowRight, Lightbulb } from 'phosphor-react';
import './TutorialView.css';

const TutorialView = ({ level, onStart }) => {
    const { tutorialContent } = level;

    // Parse text content - split into paragraphs and detect lists
    const parseContent = (text) => {
        const lines = text.split('\n');
        const elements = [];
        let currentList = [];
        let currentParagraph = [];

        lines.forEach((line, idx) => {
            const trimmedLine = line.trim();
            
            // Check if line is a bullet point
            if (trimmedLine.startsWith('•')) {
                // Save any pending paragraph
                if (currentParagraph.length > 0) {
                    elements.push({ type: 'paragraph', content: currentParagraph.join('\n') });
                    currentParagraph = [];
                }
                // Add to current list
                currentList.push(trimmedLine.substring(1).trim());
            } else if (trimmedLine === '') {
                // Empty line - save pending content
                if (currentList.length > 0) {
                    elements.push({ type: 'list', items: [...currentList] });
                    currentList = [];
                }
                if (currentParagraph.length > 0) {
                    elements.push({ type: 'paragraph', content: currentParagraph.join('\n') });
                    currentParagraph = [];
                }
            } else if (trimmedLine) {
                // Regular text line
                if (currentList.length > 0) {
                    elements.push({ type: 'list', items: [...currentList] });
                    currentList = [];
                }
                currentParagraph.push(line);
            }
        });

        // Save any remaining content
        if (currentList.length > 0) {
            elements.push({ type: 'list', items: currentList });
        }
        if (currentParagraph.length > 0) {
            elements.push({ type: 'paragraph', content: currentParagraph.join('\n') });
        }

        return elements;
    };

    const contentElements = parseContent(tutorialContent.text);

    return (
        <div className="tutorial-view fade-in">
            <div className="tutorial-header">
                <div className="icon-wrapper">
                    <BookOpen size={32} weight="duotone" color="var(--primary)" />
                </div>
                <div>
                    <h4 className="sub-header">Level {level.id} Tutorial</h4>
                    <h2 className="text-gradient">{tutorialContent.title}</h2>
                </div>
            </div>

            <div className="tutorial-content glass-panel">
                <div className="main-text">
                    {contentElements.map((element, index) => {
                        if (element.type === 'paragraph') {
                            return <p key={index}>{element.content}</p>;
                        } else if (element.type === 'list') {
                            return (
                                <ul key={index} className="tutorial-list">
                                    {element.items.map((item, i) => (
                                        <li key={i}>{item}</li>
                                    ))}
                                </ul>
                            );
                        }
                        return null;
                    })}
                </div>

                <div className="example-box">
                    <div className="box-label">Example</div>
                    <pre>{tutorialContent.example}</pre>
                </div>

                <div className="key-points">
                    <h3><Lightbulb size={20} weight="fill" color="var(--warning)" /> Key Takeaways</h3>
                    <ul>
                        {tutorialContent.keyPoints.map((point, index) => (
                            <li key={index}>{point}</li>
                        ))}
                    </ul>
                </div>

                {tutorialContent.walkthrough && (
                    <div className="tutorial-section walkthrough-section">
                        <h3>How to Pass This Level</h3>
                        <div className="walkthrough-steps">
                            {tutorialContent.walkthrough.map((step, i) => (
                                <div key={i} className="walkthrough-step">
                                    <strong>{step.title}</strong>
                                    <p>{step.text}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </div>

            <div className="tutorial-actions">
                <button className="btn btn-primary btn-large pulse" onClick={onStart}>
                    Start Exercise <ArrowRight size={20} weight="bold" />
                </button>
            </div>
        </div>
    );
};

export default TutorialView;
