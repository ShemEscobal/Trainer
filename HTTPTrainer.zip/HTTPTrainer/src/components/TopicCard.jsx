import React from 'react';
import './Dashboard.css';

const TopicCard = ({ topic, moduleCount, onClick }) => {
    return (
        <div
            className="topic-card"
            onClick={onClick}
            style={{
                '--topic-gradient': topic.gradient
            }}
        >
            <div className="topic-card-background" style={{ background: topic.gradient }}></div>
            <div className="topic-card-content">
                <div className="topic-icon">{topic.icon}</div>
                <h3 className="topic-title">{topic.title}</h3>
                <p className="topic-description">{topic.description}</p>
                <div className="topic-meta">
                    <span className="topic-module-count">{moduleCount} {moduleCount === 1 ? 'Module' : 'Modules'}</span>
                </div>
            </div>
            <div className="topic-card-arrow">→</div>
        </div>
    );
};

export default TopicCard;
