import React from 'react';
import { CheckCircle, Circle } from 'phosphor-react';
import './Layout.css';
import logo from '../assets/logo.png';

const Layout = ({ children, currentLevel, completedLevels, totalLevels, points, onBackToDashboard, onLevelSelect }) => {
  return (
    <div className="app-layout">
      <aside className="sidebar glass-panel">
        <div className="sidebar-header">
          <div className="logo-container">
            <img src={logo} alt="IOT Lab Logo" className="logo-img" />
            <h1 className="logo text-gradient">HTTP Trainer</h1>
          </div>
          {onBackToDashboard && (
            <button className="back-button" onClick={onBackToDashboard} title="Back to Dashboard">
              ← Dashboard
            </button>
          )}
        </div>

        <nav className="level-nav">
          <h3>Training Modules</h3>
          <ul>
            {Array.from({ length: totalLevels }).map((_, index) => {
              const level = index + 1;
              const isCompleted = completedLevels.includes(level);
              const isCurrent = currentLevel === level;
              // Allow access to completed levels (reviewable) or current level only
              const maxCompleted = Math.max(0, ...completedLevels);
              const isAccessible = isCompleted || level === maxCompleted + 1;

              return (
                <li
                  key={level}
                  className={`nav-item ${isCurrent ? 'active' : ''} ${isCompleted ? 'completed' : ''} ${isAccessible ? 'unlocked' : 'locked'}`}
                  onClick={() => isAccessible && onLevelSelect && onLevelSelect(level)}
                  title={!isAccessible ? 'Complete previous levels to unlock' : isCompleted ? 'Click to review' : 'Current level'}
                >
                  <span className="icon">
                    {isCompleted ? <CheckCircle size={20} weight="fill" color="var(--success)" /> :
                      isCurrent ? <Circle size={20} weight="fill" color="var(--primary)" /> :
                        <Circle size={20} color={isAccessible ? "var(--text-secondary)" : "var(--text-muted)"} />}
                  </span>
                  <span className="label">Level {level}</span>
                  {isCompleted && !isCurrent && <span className="review-badge">Review</span>}
                </li>
              );
            })}
          </ul>
        </nav>

        <div className="sidebar-footer">
          <div className="progress-bar-container">
            <div className="progress-info">
              <span>Progress</span>
              <span>{Math.round((completedLevels.length / totalLevels) * 100)}%</span>
            </div>
            <div className="progress-track">
              <div
                className="progress-fill"
                style={{ width: `${(completedLevels.length / totalLevels) * 100}%` }}
              ></div>
            </div>
          </div>
        </div>
      </aside>

      <main className="main-content">
        <header className="top-bar glass-panel">
          <div className="breadcrumbs">
            <span>Training</span> / <span className="current">Level {currentLevel}</span>
          </div>
          <div className="user-stats">
            <span className="points">🏆 {points} Points</span>
          </div>
        </header>

        <div className="content-area">
          {children}
        </div>
      </main>
    </div>
  );
};

export default Layout;
