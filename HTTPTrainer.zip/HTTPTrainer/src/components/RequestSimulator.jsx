
import React, { useState, useEffect } from 'react';
import { Play, Plus, Trash, ArrowRight } from 'phosphor-react';
import { useGame } from '../context/GameContext';
import './RequestSimulator.css';

const RequestSimulator = ({ level, completedSubTasks, setCompletedSubTasks, onLevelComplete }) => {
    const { completeLevel } = useGame();

    const [method, setMethod] = useState('GET');
    const [url, setUrl] = useState(level.endpoint || '');
    const [headers, setHeaders] = useState([{ key: '', value: '' }]);
    const [body, setBody] = useState('{\n  \n}');
    const [response, setResponse] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [activeTab, setActiveTab] = useState('headers');

    const methods = ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'HEAD', 'OPTIONS'];

    // Auto-switch to Body tab for methods that typically have a body
    useEffect(() => {
        if (['POST', 'PUT', 'PATCH'].includes(method)) {
            setActiveTab('body');
        } else {
            setActiveTab('headers');
        }
    }, [method]);

    // Reset URL when level changes
    useEffect(() => {
        setUrl(level.endpoint || '');
    }, [level]);

    const handleAddHeader = () => {
        setHeaders([...headers, { key: '', value: '' }]);
    };

    const handleRemoveHeader = (index) => {
        const newHeaders = [...headers];
        newHeaders.splice(index, 1);
        setHeaders(newHeaders);
    };

    const handleHeaderChange = (index, field, value) => {
        const newHeaders = [...headers];
        newHeaders[index][field] = value;
        setHeaders(newHeaders);
    };

    const validateRequest = () => {
        const currentUrl = url || ''; // Safety check

        // If level has sub-tasks, check against them
        if (level.subTasks) {
            const matchingTask = level.subTasks.find(t =>
                t.method === method &&
                currentUrl.includes(t.endpoint) &&
                !completedSubTasks.includes(t.id)
            );

            if (!matchingTask) return false;

            // Check body if required
            if (matchingTask.body) {
                try {
                    const jsonBody = JSON.parse(body);
                    const expectedBody = JSON.parse(matchingTask.body);
                    // Simple check for key presence/value match
                    const keysMatch = Object.keys(expectedBody).every(key => jsonBody[key] === expectedBody[key]);
                    if (!keysMatch) return false;
                } catch (e) {
                    return false;
                }
            }

            return matchingTask;
        }

        // Standard single-task validation
        if (method !== level.method) return false;
        if (!currentUrl.includes(level.endpoint)) return false;

        if (level.id === 2) { // Query Params
            if (!currentUrl.includes('?q=http')) return false;
        }

        if (level.id === 3) { // POST Body
            try {
                const jsonBody = JSON.parse(body);
                if (!jsonBody.name) return false;
            } catch (e) {
                return false;
            }
        }

        if (level.id === 4) { // Headers
            const hasAuth = headers.some(h => h.key.toLowerCase() === 'authorization' && h.value.includes('Bearer'));
            if (!hasAuth) return false;
        }

        return true;
    };

    const handleSend = async () => {
        setLoading(true);
        setResponse(null);
        setError(null);

        setTimeout(() => {
            try {
                const validationResult = validateRequest();

                if (validationResult) {
                    // Determine response data
                    let responseData;
                    let status = 200;
                    let statusText = 'OK';

                    let feedback = null;

                    if (level.subTasks) {
                        // It's a sub-task match
                        const task = validationResult;
                        responseData = task.expectedResponse;
                        status = task.method === 'POST' ? 201 : (task.expectedResponse === null ? 204 : 200);
                        statusText = task.method === 'POST' ? 'Created' : (task.expectedResponse === null ? 'No Content' : 'OK');

                        if (task.successMessage) {
                            feedback = {
                                title: task.successMessage,
                                message: task.explanation
                            };
                        }

                        // Mark task as complete
                        const newCompleted = [...completedSubTasks, task.id];
                        setCompletedSubTasks(newCompleted);

                        // Check if ALL sub-tasks are done
                        if (newCompleted.length === level.subTasks.length) {
                            completeLevel(level.id, level.points);
                        }
                    } else {
                        // Standard level
                        responseData = level.expectedResponse;
                        status = level.expectedResponse === null ? 204 : (method === 'POST' ? 201 : 200);
                        statusText = level.expectedResponse === null ? 'No Content' : (method === 'POST' ? 'Created' : 'OK');
                        completeLevel(level.id, level.points);

                        feedback = {
                            title: "Correct!",
                            message: "You successfully completed the level requirements."
                        };
                    }

                    setResponse({
                        status,
                        statusText,
                        data: responseData,
                        feedback
                    });
                } else {
                    let errorMsg = "Request failed. Check your configuration.";

                    // Smart Error Handling: Check if body data is in headers
                    if (level.subTasks) {
                        const currentUrl = url || '';
                        const currentTask = level.subTasks.find(t => t.method === method && currentUrl.includes(t.endpoint));
                        if (currentTask && currentTask.body) {
                            // Check if the expected body content is in headers
                            const expectedBody = JSON.parse(currentTask.body);
                            const headerValues = headers.map(h => h.value).join(' ');
                            const headerKeys = headers.map(h => h.key).join(' ');

                            // Check if any value from expected body is in headers
                            const valueInHeaders = Object.values(expectedBody).some(val =>
                                headerValues.includes(String(val)) || headerKeys.includes(String(val))
                            );

                            if (valueInHeaders) {
                                errorMsg = "It looks like you entered data in Headers. Please use the Body tab.";
                            } else if (method !== level.method && !level.subTasks) {
                                errorMsg = `Expected ${level.method} method, got ${method}.`;
                            }
                        }
                    }

                    if (method !== level.method && !level.subTasks) errorMsg = `Expected ${level.method} method, got ${method}.`;

                    setResponse({
                        status: 400,
                        statusText: 'Bad Request',
                        data: { error: errorMsg }
                    });
                }
            } catch (err) {
                console.error("Simulator Error:", err);
                setResponse({
                    status: 500,
                    statusText: 'Internal Error',
                    data: { error: "Something went wrong in the simulator." }
                });
            } finally {
                setLoading(false);
            }
        }, 800);
    };

    return (
        <div className="request-simulator glass-panel">
            <div className="simulator-header">
                <h3>Request Simulator</h3>
                {level.subTasks && (
                    <div className="sub-task-progress">
                        {completedSubTasks.length} / {level.subTasks.length} Tasks
                    </div>
                )}
            </div>

            <div className="control-group url-bar">
                <select
                    value={method}
                    onChange={(e) => setMethod(e.target.value)}
                    className="method-select"
                >
                    {methods.map(m => <option key={m} value={m}>{m}</option>)}
                </select>
                <input
                    type="text"
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                    placeholder="Enter URL..."
                    className="url-input"
                />
                <button
                    className="btn btn-primary send-btn"
                    onClick={handleSend}
                    disabled={loading}
                >
                    {loading ? 'Sending...' : <><Play weight="fill" /> Send</>}
                </button>
            </div>

            <div className="tabs">
                <div
                    className={`tab ${activeTab === 'headers' ? 'active' : ''}`}
                    onClick={() => setActiveTab('headers')}
                >
                    Headers
                </div>
                <div
                    className={`tab ${activeTab === 'body' ? 'active' : ''}`}
                    onClick={() => setActiveTab('body')}
                >
                    Body
                </div>
            </div>
            <div className="editor-panel">
                {activeTab === 'headers' ? (
                    <div className="headers-editor">
                        {headers.map((header, index) => (
                            <div key={index} className="header-row">
                                <input
                                    placeholder="Key"
                                    value={header.key}
                                    onChange={(e) => handleHeaderChange(index, 'key', e.target.value)}
                                />
                                <input
                                    placeholder="Value"
                                    value={header.value}
                                    onChange={(e) => handleHeaderChange(index, 'value', e.target.value)}
                                />
                                <button className="icon-btn" onClick={() => handleRemoveHeader(index)}>
                                    <Trash size={16} />
                                </button>
                            </div>
                        ))}
                        <button className="btn-text" onClick={handleAddHeader}>
                            <Plus size={16} /> Add Header
                        </button>
                    </div>
                ) : (
                    <div className="body-editor">
                        {['POST', 'PUT', 'PATCH'].includes(method) ? (
                            <>
                                <label>Request Body (JSON)</label>
                                <textarea
                                    value={body}
                                    onChange={(e) => setBody(e.target.value)}
                                    spellCheck="false"
                                />
                            </>
                        ) : (
                            <div className="empty-state">
                                <p>GET requests typically don't have a body.</p>
                                <button className="btn-text" onClick={() => setMethod('POST')}>Switch to POST</button>
                            </div>
                        )}
                    </div>
                )}
            </div>

            {response && (
                <>
                    {response.feedback && (
                        <div className="feedback-box">
                            <h4>{response.feedback.title}</h4>
                            <p>{response.feedback.message}</p>
                        </div>
                    )}

                    <div className={`response-viewer ${response.status >= 200 && response.status < 300 ? 'success' : 'error'}`}>
                        <div className="response-status">
                            <span className="status-code">{response.status} {response.statusText}</span>
                            <span className="response-time">124ms</span>
                        </div>

                        <div className="response-body">
                            {response.data ? (
                                <pre>{JSON.stringify(response.data, null, 2)}</pre>
                            ) : (
                                <div className="empty-content">(No Content)</div>
                            )}
                        </div>
                    </div>
                </>
            )}

            {completedSubTasks.length === (level.subTasks ? level.subTasks.length : 1) && (
                <div className="level-complete-action fade-in" style={{ marginTop: 'var(--space-md)', textAlign: 'right' }}>
                    <button className="btn btn-primary" onClick={onLevelComplete}>
                        Continue <ArrowRight weight="bold" />
                    </button>
                </div>
            )}
        </div>
    );
};

export default RequestSimulator;
