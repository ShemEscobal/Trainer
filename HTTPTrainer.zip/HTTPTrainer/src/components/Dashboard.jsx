import React, { useState } from 'react';
import { modules, topics, getModulesByTopic, getModuleProgress } from '../modules/moduleRegistry';
import ModuleCard from './ModuleCard';
import TopicCard from './TopicCard';
import './Dashboard.css';
import logo from '../assets/logo.png';

const Dashboard = ({ onSelectModule }) => {
    const [selectedTopic, setSelectedTopic] = useState(null);

    const filteredModules = selectedTopic
        ? getModulesByTopic(selectedTopic)
        : modules;

    const getTopicModuleCount = (topicId) => {
        return modules.filter(m => m.topic === topicId).length;
    };

    return (
        <div className="dashboard">
            <div className="dashboard-hero">
                <div className="hero-content">
                    <div className="logo-wrapper">
                        <img src={logo} alt="IOT Lab" className="hero-logo" />
                    </div>
                    <div className="hero-text-content">
                        <h1 className="hero-title">
                            IOT Lab Training Center
                        </h1>
                        <div className="hero-divider"></div>
                        <p className="hero-subtitle">
                            Professional Development Platform for Modern Technologies
                        </p>
                        <p className="hero-description">
                            Industry-leading interactive training programs designed to accelerate your technical expertise
                        </p>
                    </div>
                    <div className="hero-stats">
                        <div className="stat-card">
                            <div className="stat-number">2-6h</div>
                            <div className="stat-label">Course Duration</div>
                        </div>
                        <div className="stat-card">
                            <div className="stat-number">100%</div>
                            <div className="stat-label">Hands-On Practice</div>
                        </div>
                        <div className="stat-card">
                            <div className="stat-number">∞</div>
                            <div className="stat-label">Career Growth</div>
                        </div>
                    </div>
                </div>
                <div className="hero-background">
                    <div className="hero-grid"></div>
                    <div className="floating-shapes">
                        <div className="shape shape-circle shape-1"></div>
                        <div className="shape shape-square shape-2"></div>
                        <div className="shape shape-triangle shape-3"></div>
                        <div className="shape shape-circle shape-4"></div>
                        <div className="shape shape-hexagon shape-5"></div>
                        <div className="shape shape-square shape-6"></div>
                    </div>
                </div>
            </div>

            <div className="modules-section">
                {!selectedTopic ? (
                    <>
                        <div className="section-header">
                            <h2>Choose Your Learning Path</h2>
                            <p>Select a topic to explore training modules</p>
                        </div>

                        <div className="topics-grid">
                            {topics.map((topic) => (
                                <TopicCard
                                    key={topic.id}
                                    topic={topic}
                                    moduleCount={getTopicModuleCount(topic.id)}
                                    onClick={() => setSelectedTopic(topic.id)}
                                />
                            ))}
                        </div>
                    </>
                ) : (
                    <>
                        <div className="section-header">
                            <button className="back-to-topics" onClick={() => setSelectedTopic(null)}>
                                ← Back to Topics
                            </button>
                            <h2>{topics.find(t => t.id === selectedTopic)?.title}</h2>
                            <p>Start your journey and earn your certificate</p>
                        </div>

                        <div className="modules-grid">
                            {filteredModules.map((module, index) => {
                                const progress = getModuleProgress(module.id);
                                return (
                                    <ModuleCard
                                        key={module.id}
                                        module={module}
                                        progress={progress}
                                        onClick={() => onSelectModule(module)}
                                        animationDelay={index * 100}
                                    />
                                );
                            })}
                        </div>
                    </>
                )}
            </div>

            <div className="dashboard-footer">
                <p>© 2025 IOT Lab Research and Training Center</p>
            </div>
        </div>
    );
};

export default Dashboard;
