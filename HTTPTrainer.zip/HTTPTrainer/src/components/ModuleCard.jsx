import React from 'react';
import './Dashboard.css';

const ModuleCard = ({ module, progress, onClick, animationDelay }) => {
    const { title, description, icon, difficulty, duration, color, accentColor, isAvailable, totalLevels } = module;

    // Calculate progress percentage
    const progressPercentage = progress
        ? Math.round((progress.completedLevels / totalLevels) * 100)
        : 0;

    const hasProgress = progressPercentage > 0;

    return (
        <div
            className={`module-card ${!isAvailable ? 'module-card-disabled' : ''} ${hasProgress ? 'module-card-started' : ''}`}
            onClick={isAvailable ? onClick : null}
            style={{
                '--module-color': color,
                '--module-accent': accentColor,
                '--animation-delay': `${animationDelay}ms`
            }}
        >
            <div className="module-card-header">
                <div className="module-icon" style={{ background: `linear-gradient(135deg, ${color}, ${accentColor})` }}>
                    {icon}
                </div>
                {!isAvailable && <span className="module-badge">Coming Soon</span>}
                {hasProgress && <span className="module-badge module-badge-progress">In Progress</span>}
            </div>

            <div className="module-card-body">
                <h3 className="module-title">{title}</h3>
                <p className="module-description">{description}</p>

                <div className="module-meta">
                    <span className={`module-difficulty difficulty-${difficulty.toLowerCase()}`}>
                        {difficulty}
                    </span>
                    <span className="module-duration">⏱️ {duration}</span>
                </div>

                {hasProgress && (
                    <div className="module-progress">
                        <div className="progress-bar">
                            <div
                                className="progress-fill"
                                style={{
                                    width: `${progressPercentage}%`,
                                    background: `linear-gradient(90deg, ${color}, ${accentColor})`
                                }}
                            ></div>
                        </div>
                        <span className="progress-text">{progressPercentage}% Complete</span>
                    </div>
                )}
            </div>

            <div className="module-card-footer">
                <button className="module-button" disabled={!isAvailable}>
                    {isAvailable ? (hasProgress ? 'Continue' : 'Start Module') : 'Coming Soon'}
                </button>
            </div>
        </div>
    );
};

export default ModuleCard;
