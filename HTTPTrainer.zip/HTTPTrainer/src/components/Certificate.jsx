import React, { useState, useRef } from 'react';
import { Medal, Download } from 'phosphor-react';
import './Certificate.css';

const Certificate = () => {
    const [name, setName] = useState('');
    const [showCertificate, setShowCertificate] = useState(false);
    const [controlNumber] = useState(Math.random().toString(36).substr(2, 9).toUpperCase());
    const certificateRef = useRef(null);

    const handleGenerate = () => {
        if (name.trim()) {
            setShowCertificate(true);
        } else {
            alert("Please enter your name to generate the certificate.");
        }
    };

    const handlePrint = () => {
        window.print();
    };

    if (!showCertificate) {
        return (
            <div className="certificate-form glass-panel">
                <Medal size={64} color="var(--warning)" weight="duotone" />
                <h2 className="text-gradient">Course Completed!</h2>
                <p>You've mastered the HTTP protocol. Enter your name to generate your certificate.</p>

                <div className="input-group">
                    <input
                        type="text"
                        placeholder="Enter your name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="name-input"
                    />
                    <button className="btn btn-primary" onClick={handleGenerate}>
                        Generate Certificate
                    </button>
                </div>
            </div>
        );
    }

    return (
        <div className="certificate-container">
            <div className="certificate glass-panel" ref={certificateRef}>
                <div className="cert-border">
                    <div className="cert-header">
                        <Medal size={80} color="var(--warning)" weight="fill" />
                        <h1>Certificate of Mastery</h1>
                        <p className="subtitle">HTTP Protocol Training</p>
                    </div>

                    <div className="cert-body">
                        <p>This certifies that</p>
                        <h2 className="student-name">{name}</h2>
                        <p>has successfully completed the HTTP Trainer Course</p>
                        <p className="date">{new Date().toLocaleDateString()}</p>
                    </div>

                    <div className="cert-footer">
                        <div className="signature">
                            <span style={{ height: '24px', display: 'block' }}></span>
                            <div className="line"></div>
                            <small>Instructor</small>
                        </div>

                        <div className="qr-section">
                            <img
                                src={`https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=${encodeURIComponent(`Certificate ID: ${controlNumber}\nStudent: ${name}\nDate: ${new Date().toLocaleDateString()}`)}`}
                                alt="Certificate QR Code"
                                className="qr-code"
                            />
                            <small className="control-number">Control #: {controlNumber}</small>
                        </div>

                        <div className="signature">
                            <span style={{ height: '24px', display: 'block' }}></span>
                            <div className="line"></div>
                            <small>Platform</small>
                        </div>
                    </div>
                </div>
            </div>

            <div className="actions">
                <button className="btn btn-primary" onClick={handlePrint}>
                    <Download size={20} /> Download / Print
                </button>
            </div>
        </div>
    );
};

export default Certificate;
