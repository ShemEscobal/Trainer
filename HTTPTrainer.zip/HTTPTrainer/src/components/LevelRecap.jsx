import React from 'react';
import './LevelRecap.css';
import { CheckCircle, ArrowRight, Star } from 'phosphor-react';

const LevelRecap = ({ level, onNextLevel }) => {
    return (
        <div className="level-recap fade-in">
            <div className="recap-card glass-panel">
                <div className="recap-header">
                    <div className="success-icon">
                        <CheckCircle size={64} weight="fill" />
                    </div>
                    <h2>Level Complete!</h2>
                    <p className="points-earned">+{level.points} Points</p>
                </div>

                <div className="recap-content">
                    <div className="explanation-section">
                        <h3><Star size={24} weight="fill" /> Mission Accomplished</h3>
                        <p>{level.explanation || "You've successfully completed all tasks for this level."}</p>
                    </div>

                    {level.tutorialContent && level.tutorialContent.keyPoints && (
                        <div className="key-points-section">
                            <h3>Key Takeaways</h3>
                            <ul>
                                {level.tutorialContent.keyPoints.map((point, index) => (
                                    <li key={index}>{point}</li>
                                ))}
                            </ul>
                        </div>
                    )}
                </div>

                <div className="recap-actions">
                    <button className="btn btn-primary btn-large" onClick={onNextLevel}>
                        Next Level <ArrowRight size={20} weight="bold" />
                    </button>
                </div>
            </div>
        </div>
    );
};

export default LevelRecap;
