import React from 'react';
import { Info, CheckCircle, ArrowLeft } from 'phosphor-react';
import './LevelGuide.css';

const LevelGuide = ({ level, onShowTutorial, completedSubTasks }) => {
    return (
        <div className="level-guide glass-panel">
            <div className="guide-header">
                <div className="header-left">
                    <button className="btn-icon-text" onClick={onShowTutorial}>
                        <ArrowLeft size={18} /> Review Tutorial
                    </button>
                    <h2 className="text-gradient">{level.title}</h2>
                </div>
                <div className="points-badge">
                    <span>+{level.points} PTS</span>
                </div>
            </div>

            <p className="description">{level.description}</p>

            <div className="instruction-box">
                <div className="box-header">
                    <Info size={20} color="var(--primary)" />
                    <h3>Concept</h3>
                </div>
                <p>{level.instruction}</p>
            </div>

            <div className="task-box">
                <div className="box-header">
                    <CheckCircle size={20} color="var(--secondary)" />
                    <h3>Mission</h3>
                </div>
                <p>{level.task || "Complete all sub-tasks below to pass this level."}</p>

                {level.subTasks && (
                    <div className="sub-tasks-list">
                        {level.subTasks.map(task => {
                            const isCompleted = completedSubTasks && completedSubTasks.includes(task.id);
                            return (
                                <div key={task.id} className={`sub-task-item ${isCompleted ? 'completed' : ''}`}>
                                    <div className="task-header">
                                        <div className="task-status-icon">
                                            {isCompleted ? <CheckCircle size={16} weight="fill" color="var(--success)" /> : <div className="circle-placeholder" />}
                                        </div>
                                        <span className="method-badge">{task.method}</span>
                                        <span className="task-desc">{task.description}</span>
                                    </div>
                                    {task.hint && !isCompleted && (
                                        <div className="task-hint">
                                            <code>{task.hint}</code>
                                        </div>
                                    )}
                                </div>
                            );
                        })}
                    </div>
                )}
            </div>
        </div>
    );
};

export default LevelGuide;
