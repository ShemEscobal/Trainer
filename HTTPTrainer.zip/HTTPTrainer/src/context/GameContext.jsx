import React, { createContext, useContext, useState, useEffect } from 'react';

const GameContext = createContext();

export const useGame = () => useContext(GameContext);

export const GameProvider = ({ children }) => {
    const [currentLevel, setCurrentLevel] = useState(1);
    const [completedLevels, setCompletedLevels] = useState([]);
    const [points, setPoints] = useState(0);

    // Load progress from localStorage on mount
    useEffect(() => {
        const savedProgress = localStorage.getItem('httpTrainerProgress');
        if (savedProgress) {
            const { currentLevel, completedLevels, points } = JSON.parse(savedProgress);
            setCurrentLevel(currentLevel);
            setCompletedLevels(completedLevels);
            setPoints(points);
        }
    }, []);

    // Save progress whenever it changes
    useEffect(() => {
        localStorage.setItem('httpTrainerProgress', JSON.stringify({
            currentLevel,
            completedLevels,
            points
        }));
    }, [currentLevel, completedLevels, points]);

    const completeLevel = (levelId, levelPoints) => {
        if (!completedLevels.includes(levelId)) {
            setCompletedLevels(prev => [...prev, levelId]);
            setPoints(prev => prev + levelPoints);
        }
    };

    const nextLevel = () => {
        setCurrentLevel(prev => prev + 1);
    };

    const resetProgress = () => {
        setCurrentLevel(1);
        setCompletedLevels([]);
        setPoints(0);
        localStorage.removeItem('httpTrainerProgress');
    };

    return (
        <GameContext.Provider value={{
            currentLevel,
            setCurrentLevel,
            completedLevels,
            points,
            completeLevel,
            nextLevel,
            resetProgress
        }}>
            {children}
        </GameContext.Provider>
    );
};
