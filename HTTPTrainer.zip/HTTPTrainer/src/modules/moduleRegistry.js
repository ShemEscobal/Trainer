// Topic categories
export const topics = [
    {
        id: 'software-development',
        title: 'Software Development',
        description: 'Web development, APIs, and software engineering fundamentals',
        icon: '💻',
        color: '#800000',
        gradient: 'linear-gradient(135deg, #800000, #F59E0B)'
    },
    {
        id: 'data-science',
        title: 'Data Science & AI',
        description: 'Machine learning, data analysis, and predictive modeling',
        icon: '📊',
        color: '#DC2626',
        gradient: 'linear-gradient(135deg, #DC2626, #F87171)'
    },
    {
        id: 'iot',
        title: 'Internet of Things',
        description: 'IoT devices, sensors, and connected systems',
        icon: '🌐',
        color: '#059669',
        gradient: 'linear-gradient(135deg, #059669, #10B981)'
    },
    {
        id: 'robotics',
        title: 'Robotics',
        description: 'Robotics programming, control systems, and automation',
        icon: '🤖',
        color: '#7C3AED',
        gradient: 'linear-gradient(135deg, #7C3AED, #A78BFA)'
    }
];

// Central registry of all training modules
export const modules = [
    {
        id: 'http-protocol',
        title: 'HTTP Protocol',
        description: 'Master HTTP methods, headers, status codes, and request/response cycles',
        icon: '🌐',
        difficulty: 'Beginner',
        duration: '2-3 hours',
        color: '#800000', // Maroon
        accentColor: '#F59E0B', // Yellow
        totalLevels: 6,
        component: 'HTTPTrainer',
        isAvailable: true,
        topic: 'software-development'
    },
    {
        id: 'rest-api',
        title: 'REST API',
        description: 'Learn RESTful API design principles, best practices, and implementation',
        icon: '🔌',
        difficulty: 'Intermediate',
        duration: '3-4 hours',
        color: '#800000',
        accentColor: '#F59E0B',
        totalLevels: 8,
        component: 'RESTAPITrainer',
        isAvailable: true,
        topic: 'software-development'
    },
    {
        id: 'websockets',
        title: 'WebSockets',
        description: 'Real-time bidirectional communication with WebSockets',
        icon: '⚡',
        difficulty: 'Intermediate',
        duration: '2-3 hours',
        color: '#800000',
        accentColor: '#F59E0B',
        totalLevels: 6,
        component: 'WebSocketsTrainer',
        isAvailable: false, // Coming soon
        topic: 'software-development'
    },
    {
        id: 'database',
        title: 'Database Fundamentals',
        description: 'SQL queries, database design, normalization, and optimization',
        icon: '🗄️',
        difficulty: 'Beginner',
        duration: '4-5 hours',
        color: '#800000',
        accentColor: '#F59E0B',
        totalLevels: 10,
        component: 'DatabaseTrainer',
        isAvailable: false, // Coming soon
        topic: 'software-development'
    },
    {
        id: 'linear-regression',
        title: 'Linear Regression',
        description: 'ML modeling with model saving and evaluation using sample datasets',
        icon: '📊',
        difficulty: 'Advanced',
        duration: '5-6 hours',
        color: '#DC2626', // Red
        accentColor: '#F87171',
        totalLevels: 12,
        component: 'LinearRegressionTrainer',
        isAvailable: false, // Coming soon
        topic: 'data-science'
    }
];

export const getModuleById = (id) => {
    return modules.find(module => module.id === id);
};

export const getAvailableModules = () => {
    return modules.filter(module => module.isAvailable);
};

export const getModulesByTopic = (topicId) => {
    return modules.filter(module => module.topic === topicId);
};

export const getTopicById = (id) => {
    return topics.find(topic => topic.id === id);
};

export const getModuleProgress = (moduleId) => {
    const savedProgress = localStorage.getItem(`module_${moduleId}_progress`);
    return savedProgress ? JSON.parse(savedProgress) : null;
};
