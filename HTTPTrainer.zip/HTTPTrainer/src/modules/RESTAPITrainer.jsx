import React, { useState, useEffect } from 'react';
import { restApiLevels } from '../data/restApiLevels';
import { useGame } from '../context/GameContext';
import Layout from '../components/Layout';
import TutorialView from '../components/TutorialView';
import LevelGuide from '../components/LevelGuide';
import RequestSimulator from '../components/RequestSimulator';
import LevelRecap from '../components/LevelRecap';
import Certificate from '../components/Certificate';

const RESTAPITrainer = ({ onBackToDashboard }) => {
    const totalLevels = restApiLevels.length;
    const { points } = useGame();

    // Module-specific level tracking
    const [currentLevel, setCurrentLevel] = useState(() => {
        const saved = localStorage.getItem('restapi_currentLevel');
        return saved ? parseInt(saved) : 1;
    });

    const [completedLevels, setCompletedLevels] = useState(() => {
        const saved = localStorage.getItem('restapi_completedLevels');
        return saved ? JSON.parse(saved) : [];
    });

    const [showTutorial, setShowTutorial] = useState(() => {
        // Don't show tutorial by default if reviewing a completed level
        const saved = localStorage.getItem('restapi_currentLevel');
        const level = saved ? parseInt(saved) : 1;
        const completedSaved = localStorage.getItem('restapi_completedLevels');
        const completed = completedSaved ? JSON.parse(completedSaved) : [];
        return !completed.includes(level);
    });
    const [showRecap, setShowRecap] = useState(false);
    const [completedSubTasks, setCompletedSubTasks] = useState([]);

    const level = restApiLevels.find((l) => l.id === currentLevel) || restApiLevels[0];

    // Save progress to localStorage
    useEffect(() => {
        localStorage.setItem('restapi_currentLevel', currentLevel.toString());
        localStorage.setItem('restapi_completedLevels', JSON.stringify(completedLevels));
    }, [currentLevel, completedLevels]);

    // Handle level selection - show tutorial only for new levels, not for reviewing completed ones
    // Only run when user manually selects a level, not when progressing naturally
    const handleLevelSelection = (newLevel) => {
        setCurrentLevel(newLevel);
        const isReviewing = completedLevels.includes(newLevel);
        setShowTutorial(!isReviewing);
        setShowRecap(false);
        setCompletedSubTasks([]);
    };

    const handleLevelComplete = () => {
        // Mark level as completed
        if (!completedLevels.includes(currentLevel)) {
            setCompletedLevels([...completedLevels, currentLevel]);
        }
        setShowRecap(true);
    };

    const handleContinueFromRecap = () => {
        setShowRecap(false);
        const nextLevel = currentLevel + 1;
        setCurrentLevel(nextLevel);
        setShowTutorial(true);
        setCompletedSubTasks([]);
    };

    const handleStartExercise = () => {
        setShowTutorial(false);
    };

    const handleToggleTutorial = () => {
        setShowTutorial(!showTutorial);
    };

    if (currentLevel > totalLevels) {
        return (
            <div className="app-layout">
                <Certificate
                    userName="Congratulations!"
                    courseName="REST API Mastery"
                    completionDate={new Date().toLocaleDateString()}
                    totalPoints={points}
                />
            </div>
        );
    }

    return (
        <Layout
            currentLevel={currentLevel}
            completedLevels={completedLevels}
            totalLevels={totalLevels}
            points={points}
            onBackToDashboard={onBackToDashboard}
            onLevelSelect={handleLevelSelection}
        >
            {showRecap ? (
                <LevelRecap
                    level={level}
                    onNextLevel={handleContinueFromRecap}
                />
            ) : showTutorial ? (
                <TutorialView
                    level={level}
                    onStart={handleStartExercise}
                />
            ) : (
                <div className="level-container">
                    <LevelGuide
                        level={level}
                        completedSubTasks={completedSubTasks}
                        onShowTutorial={handleToggleTutorial}
                    />
                    <RequestSimulator
                        level={level}
                        completedSubTasks={completedSubTasks}
                        setCompletedSubTasks={setCompletedSubTasks}
                        onLevelComplete={handleLevelComplete}
                    />
                </div>
            )}
        </Layout>
    );
};

export default RESTAPITrainer;
