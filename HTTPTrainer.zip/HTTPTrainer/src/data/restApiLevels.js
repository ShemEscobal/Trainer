// REST API Training Module Levels
export const restApiLevels = [
    // --- MODULE 1: CORE PRINCIPLES ---
    {
        id: 1,
        title: "REST Fundamentals",
        description: "Learn the core principles of RESTful architecture.",
        points: 500,
        instruction: "REST APIs use HTTP methods to perform operations on resources.",
        tutorialContent: {
            title: "Understanding REST",
            text: "REST (Representational State Transfer) is an architectural style for building web services. It uses standard HTTP methods to interact with resources (data).\n\nKey Principles:\n\n• Everything is a Resource - Users, products, orders are all resources\n• Uniform Interface - Use standard HTTP methods (GET, POST, PUT, DELETE)\n• Stateless - Each request contains all information needed, server doesn't remember previous requests\n\nRESTful APIs are predictable, scalable, and easy to understand.",
            example: "GET /api/users      → Get list of users\nGET /api/users/1    → Get specific user\nPOST /api/users     → Create new user\nPUT /api/users/1    → Update user\nDELETE /api/users/1 → Delete user",
            keyPoints: [
                "Resources are nouns (users, products, orders)",
                "Stateless: Each request is independent and self-contained",
                "Use standard HTTP methods for operations",
                "Responses should be cacheable when possible"
            ],
            walkthrough: [
                {
                    title: "Your First REST Request",
                    text: "You'll retrieve a list of books using a GET request. GET is the safest method - it only reads data, never changes it."
                },
                {
                    title: "How to Complete",
                    text: "Select 'GET' method from the dropdown, enter '/api/books' as the endpoint, and click Send. That's it!"
                }
            ]
        },
        subTasks: [
            {
                id: 't1',
                method: 'GET',
                endpoint: '/api/books',
                description: '1. GET: Retrieve all books.',
                hint: 'URL: /api/books',
                expectedResponse: { books: [{ id: 1, title: "REST Guide" }] },
                successMessage: "Collection retrieved!",
                explanation: "You fetched a collection of resources."
            }
        ]
    },
    {
        id: 2,
        title: "Resource Naming",
        description: "Master URL patterns.",
        points: 550,
        instruction: "Use plural nouns and hierarchy.",
        tutorialContent: {
            title: "Naming Conventions",
            text: "Good REST API URLs are intuitive and predictable. Follow these best practices:\n\n• Use plural nouns for collections (users, not user)\n• Use lowercase letters\n• Use hyphens for multi-word resources\n• Show hierarchy with forward slashes\n• Avoid verbs in URLs (use HTTP methods instead)\n\nGood URL design makes your API self-documenting and easy to use.",
            example: "✅ Good Examples:\n/api/products\n/api/users/123\n/api/users/123/orders\n/api/blog-posts\n\n❌ Bad Examples:\n/api/getProducts\n/api/product_list\n/api/User\n/api/getUserOrders?id=123",
            keyPoints: [
                "Plural nouns for collections: /api/users not /api/user",
                "Lowercase URLs: /api/products not /api/Products",
                "Hyphens for readability: /api/blog-posts not /api/blog_posts",
                "Hierarchy shows relationships: /api/users/1/orders"
            ],
            walkthrough: [
                {
                    title: "Proper Resource Naming",
                    text: "You'll access a list of videos. Notice the URL uses 'videos' (plural) and lowercase."
                },
                {
                    title: "Send the Request",
                    text: "Method: GET, Endpoint: /api/videos. This follows REST naming conventions perfectly."
                }
            ]
        },
        subTasks: [
            {
                id: 't1',
                method: 'GET',
                endpoint: '/api/users/42/orders',
                description: '1. GET: Fetch orders for user 42.',
                hint: 'URL: /api/users/42/orders',
                expectedResponse: { orders: [] },
                successMessage: "Hierarchy understood!",
                explanation: "You used a hierarchical URL structure."
            }
        ]
    },
    {
        id: 3,
        title: "HTTP Methods Mapping",
        description: "Map CRUD to HTTP methods.",
        points: 600,
        instruction: "Create=POST, Read=GET, Update=PUT, Delete=DELETE.",
        tutorialContent: {
            title: "The CRUD Mapping",
            text: "REST APIs use specific HTTP methods for different operations. Each method has a clear purpose:\n\n• GET - Retrieve data (Read)\n• POST - Create new resources\n• PUT - Update existing resources\n• DELETE - Remove resources\n\nNever use GET to delete or modify data! Always use the appropriate HTTP method for the operation you're performing.",
            example: "GET /api/users      → List all users\nGET /api/users/1    → Get user #1\nPOST /api/users     → Create new user\nPUT /api/users/1    → Update user #1\nDELETE /api/users/1 → Delete user #1",
            keyPoints: [
                "GET: Safe and read-only, doesn't change data",
                "POST: Not idempotent, creates new resources",
                "PUT: Idempotent, replaces entire resource",
                "DELETE: Idempotent, removes a resource permanently"
            ],
            walkthrough: [
                {
                    title: "Understanding DELETE",
                    text: "The DELETE method removes a resource from the server. Send a DELETE request to /api/cache to clear it."
                },
                {
                    title: "Method Selection",
                    text: "Choose 'DELETE' from the method dropdown, enter the endpoint '/api/cache', and send the request."
                }
            ]
        },
        subTasks: [
            {
                id: 't1',
                method: 'DELETE',
                endpoint: '/api/cache',
                description: '1. DELETE: Clear the cache.',
                hint: 'Method: DELETE, Endpoint: /api/cache',
                expectedResponse: {},
                successMessage: "Cache cleared!",
                explanation: "You used the correct method for removal."
            }
        ]
    },
    {
        id: 4,
        title: "Status Codes in REST",
        description: "Communicate results clearly.",
        points: 650,
        instruction: "201 Created, 204 No Content, 404 Not Found.",
        tutorialContent: {
            title: "Speaking Status",
            text: "HTTP status codes tell clients what happened with their request. Different operations return different status codes:\n\n• 200 OK - Standard success response\n• 201 Created - Resource was successfully created\n• 204 No Content - Success but no data to return\n• 404 Not Found - Resource doesn't exist\n\nUsing the correct status code helps clients understand the result without parsing the response body.",
            example: "POST /api/users    → 201 Created\nGET /api/users/1   → 200 OK\nDELETE /api/users/1 → 204 No Content\nGET /api/users/999 → 404 Not Found",
            keyPoints: [
                "201 Created: Used when POST successfully creates a new resource",
                "204 No Content: Success with empty response (often for DELETE)",
                "404 Not Found: The requested resource doesn't exist",
                "Always return appropriate status codes for better API design"
            ],
            walkthrough: [
                {
                    title: "Create a Note",
                    text: "You need to create a new note by sending a POST request to /api/notes (plural) with JSON body data."
                },
                {
                    title: "Request Setup",
                    text: "Method: POST, Endpoint: /api/notes, Body: {\"text\":\"Hello\"}. Make sure to use the correct endpoint with 'notes' in plural form."
                }
            ]
        },
        subTasks: [
            {
                id: 't1',
                method: 'POST',
                endpoint: '/api/notes',
                body: '{"text":"Hello"}',
                description: '1. POST: Create a note (Expect 201).',
                hint: 'Endpoint: /api/notes (plural), Body: {"text":"Hello"}',
                expectedResponse: { id: 1, text: "Hello" },
                successMessage: "201 Created!",
                explanation: "Correct status code for creation."
            }
        ]
    },
    {
        id: 5,
        title: "Full CRUD Lifecycle",
        description: "Manage a resource from birth to death.",
        points: 700,
        instruction: "Create, Read, Update, Delete a 'Project'.",
        tutorialContent: {
            title: "The Complete CRUD Lifecycle",
            text: "CRUD stands for Create, Read, Update, Delete - the four basic operations for any resource. In REST, these map to HTTP methods:\n\n• CREATE → POST /api/projects\n• READ → GET /api/projects/1\n• UPDATE → PUT /api/projects/1\n• DELETE → DELETE /api/projects/1\n\nMost real-world APIs follow this pattern. Understanding CRUD is essential for working with any REST API.",
            example: "Complete Lifecycle Example:\n\n1. POST /api/projects\n   Body: {\"name\":\"Alpha\"}\n   Result: Creates project with ID 1\n\n2. GET /api/projects/1\n   Result: Retrieves project details\n\n3. PUT /api/projects/1\n   Body: {\"name\":\"Beta\"}\n   Result: Updates project name\n\n4. DELETE /api/projects/1\n   Result: Removes the project",
            keyPoints: [
                "POST creates new resources (returns the created item)",
                "GET reads resources safely (doesn't change anything)",
                "PUT updates entire resources (send complete data)",
                "DELETE removes resources permanently"
            ],
            walkthrough: [
                {
                    title: "Step 1: Create a Project",
                    text: "First, create a new project using POST to /api/projects with body: {\"name\":\"Alpha\"}"
                },
                {
                    title: "Step 2: Update the Project",
                    text: "Next, update the project using PUT to /api/projects/1 with body: {\"name\":\"Beta\"}. This changes the name from Alpha to Beta."
                }
            ]
        },
        subTasks: [
            {
                id: 't1',
                method: 'POST',
                endpoint: '/api/projects',
                body: '{"name":"Alpha"}',
                description: '1. Create Project',
                hint: 'POST /api/projects',
                expectedResponse: { id: 1, name: "Alpha" },
                successMessage: "Created!",
                explanation: "Step 1 done."
            },
            {
                id: 't2',
                method: 'PUT',
                endpoint: '/api/projects/1',
                body: '{"name":"Beta"}',
                description: '2. Update Project',
                hint: 'PUT /api/projects/1',
                expectedResponse: { id: 1, name: "Beta" },
                successMessage: "Updated!",
                explanation: "Step 2 done."
            }
        ]
    },

    // --- MODULE 2: ADVANCED RESOURCE DESIGN ---
    {
        id: 6,
        title: "Nested Resources",
        description: "Handling relationships.",
        points: 750,
        instruction: "Access resources that belong to other resources.",
        tutorialContent: {
            title: "Parent-Child Relationships",
            text: "Resources often have relationships. A blog has comments, a user has orders, a magazine has articles. REST uses URL nesting to show these relationships:\n\n• /api/blogs/1/comments - Comments belonging to blog 1\n• /api/users/5/orders - Orders belonging to user 5\n• /api/magazines/2/articles - Articles in magazine 2\n\nBest Practice: Don't nest more than 2 levels deep. Keep URLs simple and readable.",
            example: "Good Nesting:\nGET /api/blogs/1/comments\nPOST /api/blogs/1/comments\nGET /api/users/3/orders/12\n\nToo Deep (Avoid):\n/api/countries/1/cities/5/buildings/10/rooms/3",
            keyPoints: [
                "Show ownership in URL structure",
                "Maximum 2 levels of nesting for readability",
                "Makes relationships explicit and clear",
                "Alternative: Use query params (?blog_id=1)"
            ],
            walkthrough: [
                {
                    title: "Accessing Nested Resources",
                    text: "You'll fetch all comments that belong to blog post #1. The URL structure shows this relationship."
                },
                {
                    title: "Send the Request",
                    text: "Method: GET, Endpoint: /api/blogs/1/comments. This retrieves comments nested under blog 1."
                }
            ]
        },
        subTasks: [
            {
                id: 't1',
                method: 'GET',
                endpoint: '/api/blogs/1/comments',
                description: '1. GET: Fetch comments for blog 1.',
                hint: 'URL: /api/blogs/1/comments',
                expectedResponse: { comments: [] },
                successMessage: "Nested access!",
                explanation: "You accessed a child resource."
            }
        ]
    },
    {
        id: 7,
        title: "Singleton Resources",
        description: "Resources that only have one instance.",
        points: 800,
        instruction: "Use /me or /config for singletons.",
        tutorialContent: {
            title: "The One and Only",
            text: "Some resources are unique - there's only one instance in a given context:\n\n• /api/me - The currently logged-in user\n• /api/config - Application configuration\n• /api/dashboard - User's personal dashboard\n\nSingletons don't need IDs because there's only one. This provides convenient shortcuts for common operations.",
            example: "Singleton Examples:\n\nGET /api/me\n→ Returns your profile\n\nPUT /api/me\n→ Updates your profile\n\nGET /api/settings\n→ Your settings\n\nvs Collection:\nGET /api/users/123",
            keyPoints: [
                "No ID needed - context determines which one",
                "Common for 'current user' scenarios",
                "Convenience aliases make APIs easier to use",
                "Context-aware: /api/me knows who you are"
            ],
            walkthrough: [
                {
                    title: "Accessing Your Profile",
                    text: "The /api/me endpoint is a singleton - it always returns the current user's profile without needing an ID."
                },
                {
                    title: "Make the Request",
                    text: "Method: GET, Endpoint: /api/me. No ID needed since it's context-aware."
                }
            ]
        },
        subTasks: [
            {
                id: 't1',
                method: 'GET',
                endpoint: '/api/me',
                description: '1. GET: Fetch current user profile.',
                hint: 'URL: /api/me',
                expectedResponse: { username: "player1" },
                successMessage: "It's you!",
                explanation: "Singleton resource accessed."
            }
        ]
    },
    {
        id: 8,
        title: "Filtering & Searching",
        description: "Refining collections.",
        points: 850,
        instruction: "Use query parameters for filtering.",
        tutorialContent: {
            title: "Narrowing Down Results",
            text: "Query parameters let clients filter large collections to find exactly what they need:\n\n• ?color=red - Items with red color\n• ?active=true - Only active items\n• ?role=admin - Users with admin role\n• ?category=books&inStock=true - Multiple filters\n\nFilters don't change the resource structure, just which items are returned.",
            example: "Filtering Examples:\n\nGET /api/items?color=red\n→ Red items only\n\nGET /api/users?active=true&role=admin\n→ Active admin users\n\nGET /api/products?category=electronics&price_max=1000\n→ Electronics under $1000",
            keyPoints: [
                "Keep URL structure clean - filters are query params",
                "Combine multiple filters with & (ampersand)",
                "Use descriptive parameter names",
                "Return empty array if no matches, not an error"
            ],
            walkthrough: [
                {
                    title: "Filter by Color",
                    text: "You'll search for items with a specific color using a query parameter."
                },
                {
                    title: "Add Query Parameter",
                    text: "Method: GET, Endpoint: /api/items?color=red. The ?color=red filters the results."
                }
            ]
        },
        subTasks: [
            {
                id: 't1',
                method: 'GET',
                endpoint: '/api/items?color=red',
                description: '1. GET: Find red items.',
                hint: 'URL: /api/items?color=red',
                expectedResponse: { items: [{ name: "Apple", color: "red" }] },
                successMessage: "Filtered!",
                explanation: "Query params used for filtering."
            }
        ]
    },
    {
        id: 9,
        title: "Sorting & Pagination",
        description: "Managing large datasets.",
        points: 900,
        instruction: "Use sort, limit, and offset/page.",
        tutorialContent: {
            title: "Order and Limits",
            text: "Large collections need pagination to prevent overwhelming responses. Common patterns:\n\n• ?limit=10 - Return only 10 items\n• ?page=2 - Get second page\n• ?offset=20 - Skip first 20 items\n• ?sort=date or ?sort=-date (descending)\n\nAlways provide sensible defaults (e.g., limit=20) to protect server and clients.",
            example: "Pagination Examples:\n\nGET /api/news?limit=10\n→ First 10 items\n\nGET /api/news?page=2&limit=10\n→ Items 11-20\n\nGET /api/products?sort=-created_at&limit=5\n→ 5 newest products\n\nGET /api/users?sort=name&offset=50&limit=25\n→ Users 51-75, sorted by name",
            keyPoints: [
                "Default limits prevent accidental huge responses",
                "Allow client control with limit/page parameters",
                "Use minus sign for descending sort: -date",
                "Include total count in response when possible"
            ],
            walkthrough: [
                {
                    title: "Sort and Limit Results",
                    text: "You'll fetch the 5 latest news items, sorted by date."
                },
                {
                    title: "Apply Parameters",
                    text: "Method: GET, Endpoint: /api/news?sort=date&limit=5. This sorts and limits the response."
                }
            ]
        },
        subTasks: [
            {
                id: 't1',
                method: 'GET',
                endpoint: '/api/news?sort=date&limit=5',
                description: '1. GET: 5 latest news items.',
                hint: 'URL: /api/news?sort=date&limit=5',
                expectedResponse: { news: [], count: 5 },
                successMessage: "Sorted and Limited!",
                explanation: "Pagination parameters applied."
            }
        ]
    },
    {
        id: 10,
        title: "Field Selection",
        description: "Partial responses.",
        points: 950,
        instruction: "Allow clients to request specific fields to save bandwidth.",
        tutorialContent: {
            title: "Sparse Fieldsets",
            text: "Sometimes clients only need a few fields, not the entire resource. Field selection (sparse fieldsets) lets clients specify exactly what they want:\n\n• ?fields=id,name - Only ID and name\n• ?fields=email,phone - Only contact info\n\nThis reduces payload size, saves bandwidth, and improves performance - especially important for mobile apps.",
            example: "Field Selection Examples:\n\nFull Response:\nGET /api/users/1\n{ id: 1, name: \"Alice\", email: \"...\", phone: \"...\", address: \"...\", ... }\n\nPartial Response:\nGET /api/users/1?fields=id,name\n{ id: 1, name: \"Alice\" }\n\nMultiple Resources:\nGET /api/users?fields=id,name,email\n[{ id: 1, name: \"Alice\", email: \"...\" }, ...]",
            keyPoints: [
                "Reduces payload size significantly",
                "Essential for mobile and low-bandwidth scenarios",
                "Comma-separated list of field names",
                "Only requested fields are included in response"
            ],
            walkthrough: [
                {
                    title: "Request Specific Fields",
                    text: "You'll fetch users but only get their ID and name, skipping all other fields like email, phone, etc."
                },
                {
                    title: "Use Field Parameter",
                    text: "Method: GET, Endpoint: /api/users?fields=id,name. Response will only contain those two fields."
                }
            ]
        },
        subTasks: [
            {
                id: 't1',
                method: 'GET',
                endpoint: '/api/users?fields=id,name',
                description: '1. GET: Fetch only ID and Name.',
                hint: 'URL: /api/users?fields=id,name',
                expectedResponse: { users: [{ id: 1, name: "Alice" }] }, // No email
                successMessage: "Optimized!",
                explanation: "Only requested fields returned."
            }
        ]
    },

    // --- MODULE 3: CONTENT NEGOTIATION ---
    {
        id: 11,
        title: "Media Types",
        description: "MIME types explained.",
        points: 1000,
        instruction: "application/json, application/xml, text/csv.",
        tutorialContent: {
            title: "Understanding Data Formats",
            text: "Media Types (MIME types) tell applications how to interpret data. The same resource can be represented in different formats:\n\n• application/json - JSON format (most common)\n• application/xml - XML format\n• text/csv - CSV spreadsheet format\n• text/html - HTML page\n• application/pdf - PDF document\n\nAPIs use the Accept header (request) and Content-Type header (response) to communicate format.",
            example: "Common Media Types:\n\napplication/json\n→ {\"name\": \"Alice\"}\n\napplication/xml\n→ <user><name>Alice</name></user>\n\ntext/csv\n→ id,name\n   1,Alice\n\nVendor-specific:\napplication/vnd.github+json",
            keyPoints: [
                "Standard identifiers for data formats",
                "Client uses Accept header to request format",
                "Server uses Content-Type to indicate format",
                "Vendor-specific types: application/vnd.company+json"
            ],
            walkthrough: [
                {
                    title: "Request CSV Format",
                    text: "You'll request data in CSV format by setting the Accept header to text/csv."
                },
                {
                    title: "Add Accept Header",
                    text: "Method: GET, Endpoint: /api/export, Headers: {\"Accept\":\"text/csv\"}. Server will respond with CSV data."
                }
            ]
        },
        subTasks: [
            {
                id: 't1',
                method: 'GET',
                endpoint: '/api/export',
                headers: '{"Accept":"text/csv"}',
                description: '1. GET: Request CSV format.',
                hint: 'Header: Accept: text/csv',
                expectedResponse: "id,name\n1,Alice",
                successMessage: "CSV Received!",
                explanation: "Server returned text/csv."
            }
        ]
    },
    {
        id: 12,
        title: "Content Negotiation",
        description: "The Accept header.",
        points: 1050,
        instruction: "Client asks (Accept), Server answers (Content-Type).",
        tutorialContent: {
            title: "Negotiating Response Format",
            text: "Content negotiation allows clients and servers to agree on a response format:\n\nClient Request:\n• Accept: application/json - Please send JSON\n• Accept: application/xml - Please send XML\n• Accept: */* - Any format is fine\n\nServer Response:\n• Content-Type: application/json - I'm sending JSON\n• 406 Not Acceptable - I can't provide that format\n\nThis decouples the resource from its representation.",
            example: "Content Negotiation Flow:\n\n1. Client Request:\n   GET /api/users/1\n   Accept: application/xml\n\n2. Server Response:\n   Content-Type: application/xml\n   <user><name>Alice</name></user>\n\n3. If unsupported:\n   406 Not Acceptable",
            keyPoints: [
                "Client requests format with Accept header",
                "Server responds with Content-Type header",
                "Decouples data from representation format",
                "Return 406 if format cannot be provided"
            ],
            walkthrough: [
                {
                    title: "Request XML Format",
                    text: "You'll request data in XML format using the Accept header."
                },
                {
                    title: "Set Accept Header",
                    text: "Method: GET, Endpoint: /api/data, Headers: {\"Accept\":\"application/xml\"}. Server will negotiate and return XML."
                }
            ]
        },
        subTasks: [
            {
                id: 't1',
                method: 'GET',
                endpoint: '/api/data',
                headers: '{"Accept":"application/xml"}',
                description: '1. GET: Ask for XML.',
                hint: 'Header: Accept: application/xml',
                expectedResponse: "<data></data>",
                successMessage: "XML Served!",
                explanation: "Content negotiation successful."
            }
        ]
    },
    {
        id: 13,
        title: "JSON API Standard",
        description: "Standardized JSON structures.",
        points: 1100,
        instruction: "Using a spec like jsonapi.org.",
        tutorialContent: {
            title: "Stop Reinventing the Wheel",
            text: "JSON API (jsonapi.org) is a standardized specification for building APIs in JSON. Instead of everyone creating their own structure, JSON API provides:\n\n• Standard envelope: { data, included, meta }\n• Resource structure: { type, id, attributes, relationships }\n• Standard error format\n• Pagination conventions\n• Filtering and sorting patterns\n\nUsing standards makes APIs predictable and easier to learn.",
            example: "JSON API Response:\n\n{\n  \"data\": {\n    \"type\": \"articles\",\n    \"id\": \"1\",\n    \"attributes\": {\n      \"title\": \"JSON API\",\n      \"body\": \"...\"\n    },\n    \"relationships\": {\n      \"author\": { \"data\": { \"type\": \"people\", \"id\": \"9\" }}\n    }\n  }\n}",
            keyPoints: [
                "Predictable, consistent structure across all endpoints",
                "Includes metadata and relationship information",
                "Media type: application/vnd.api+json",
                "Reduces API design decisions and client confusion"
            ],
            walkthrough: [
                {
                    title: "Use JSON API Format",
                    text: "Request data using the JSON API standard media type."
                },
                {
                    title: "Set Media Type",
                    text: "Method: GET, Endpoint: /api/articles, Headers: {\"Accept\":\"application/vnd.api+json\"}."
                }
            ]
        },
        subTasks: [
            {
                id: 't1',
                method: 'GET',
                endpoint: '/api/articles',
                headers: '{"Accept":"application/vnd.api+json"}',
                description: '1. GET: Request JSON API format.',
                hint: 'Header: Accept: application/vnd.api+json',
                expectedResponse: { data: [] },
                successMessage: "Standardized!",
                explanation: "Used standard media type."
            }
        ]
    },
    {
        id: 14,
        title: "XML Support",
        description: "Handling legacy formats.",
        points: 1150,
        instruction: "Sometimes you need XML.",
        tutorialContent: {
            title: "Legacy Integration",
            text: "While JSON dominates modern APIs, XML is still widely used in enterprise systems, SOAP services, and legacy integrations:\n\n• More verbose than JSON\n• Strict schemas (XSD) for validation\n• Supports attributes and namespaces\n• Required for many enterprise/government systems\n\nModern APIs should support both JSON and XML for maximum compatibility.",
            example: "XML vs JSON:\n\nJSON:\n{\n  \"user\": {\n    \"name\": \"Bob\",\n    \"age\": 30\n  }\n}\n\nXML:\n<user>\n  <name>Bob</name>\n  <age>30</age>\n</user>\n\nOr with attributes:\n<user name=\"Bob\" age=\"30\" />",
            keyPoints: [
                "Verbose but highly structured format",
                "Schemas (XSD) provide strong validation",
                "Still required for many enterprise integrations",
                "Use Content-Type: application/xml when sending"
            ],
            walkthrough: [
                {
                    title: "Send XML Data",
                    text: "You'll send XML data in the request body with the appropriate Content-Type header."
                },
                {
                    title: "POST XML Request",
                    text: "Method: POST, Endpoint: /api/soap-gateway, Headers: {\"Content-Type\":\"application/xml\"}, Body: <request>test</request>"
                }
            ]
        },
        subTasks: [
            {
                id: 't1',
                method: 'POST',
                endpoint: '/api/soap-gateway',
                headers: '{"Content-Type":"application/xml"}',
                body: '<request>test</request>',
                description: '1. POST: Send XML body.',
                hint: 'Content-Type: application/xml',
                expectedResponse: { status: "processed" },
                successMessage: "XML Parsed!",
                explanation: "Server accepted XML input."
            }
        ]
    },

    // --- MODULE 4: ADVANCED INTERACTIONS ---
    {
        id: 15,
        title: "Idempotency",
        description: "Safe retries.",
        points: 1200,
        instruction: "Making the same request multiple times has same effect as once.",
        tutorialContent: {
            title: "Safe to Retry?",
            text: "Idempotency means repeating the same request has the same effect as doing it once. Critical for unreliable networks:\n\nIdempotent Methods:\n• GET - Reading same data multiple times is safe\n• PUT - Updating to same value multiple times = one update\n• DELETE - Deleting already-deleted resource = same result\n\nNOT Idempotent:\n• POST - Creates duplicate resources each time\n\nFor POST, use Idempotency-Key header to make it safe.",
            example: "Idempotency Examples:\n\nDELETE /api/users/1\n1st call: 204 (deleted)\n2nd call: 404 (already gone)\nResult: User is deleted (same outcome)\n\nPOST /api/payments\n1st call: Charges $100\n2nd call: Charges $100 AGAIN!\n\nPOST /api/payments\nIdempotency-Key: txn_123\n1st call: Charges $100\n2nd call: Returns same result, NO charge\nResult: Only charged once (safe!)",
            keyPoints: [
                "GET, PUT, DELETE are naturally idempotent",
                "POST is NOT idempotent - can create duplicates",
                "Use Idempotency-Key header to make POST safe",
                "Crucial for network reliability and retry logic"
            ],
            walkthrough: [
                {
                    title: "Safe Payment Processing",
                    text: "You'll send a payment request with an Idempotency-Key. Even if sent twice, it will only charge once."
                },
                {
                    title: "Add Idempotency Key",
                    text: "Method: POST, Endpoint: /api/charge, Headers: {\"Idempotency-Key\":\"txn_123\"}. Server ensures charge happens only once."
                }
            ]
        },
        subTasks: [
            {
                id: 't1',
                method: 'POST',
                endpoint: '/api/charge',
                headers: '{"Idempotency-Key":"txn_123"}',
                description: '1. POST: Charge card with Idempotency Key.',
                hint: 'Header: Idempotency-Key: txn_123',
                expectedResponse: { status: "charged" },
                successMessage: "Safe Charge!",
                explanation: "Server ensures charge happens only once."
            }
        ]
    },
    {
        id: 16,
        title: "PATCH vs PUT Deep Dive",
        description: "Partial vs Full updates.",
        points: 1250,
        instruction: "PATCH is for delta updates.",
        tutorialContent: {
            title: "Partial vs Complete Updates",
            text: "PUT and PATCH both update resources, but work differently:\n\nPUT - Complete Replacement:\n• Replaces entire resource\n• Must send all fields\n• Missing fields get deleted/reset\n\nPATCH - Partial Update:\n• Updates only specified fields\n• Other fields remain unchanged\n• More efficient for small changes\n\nUse PATCH for minor edits, PUT for full replacements.",
            example: "Example Comparison:\n\nCurrent State:\n{ name: 'Alice', email: 'a@example.com', age: 30 }\n\nPUT /api/users/1\nBody: { name: 'Bob' }\nResult: { name: 'Bob' }\nProblem: Email and age were erased!\n\nPATCH /api/users/1\nBody: { name: 'Bob' }\nResult: { name: 'Bob', email: 'a@example.com', age: 30 }\nSuccess: Only name changed, others preserved!",
            keyPoints: [
                "PUT replaces entire resource - send complete data",
                "PATCH updates specific fields - send only changes",
                "PATCH saves bandwidth and prevents data loss",
                "Use PATCH for minor edits, PUT for full replacements"
            ],
            walkthrough: [
                {
                    title: "Partial Configuration Update",
                    text: "You'll update only the theme setting using PATCH, leaving other config values unchanged."
                },
                {
                    title: "Use PATCH Method",
                    text: "Method: PATCH, Endpoint: /api/config, Body: {\"theme\":\"dark\"}. Other settings remain untouched."
                }
            ]
        },
        subTasks: [
            {
                id: 't1',
                method: 'PATCH',
                endpoint: '/api/config',
                body: '{"theme":"dark"}',
                description: '1. PATCH: Update only the theme.',
                hint: 'Method: PATCH',
                expectedResponse: { theme: "dark", lang: "en" },
                successMessage: "Patched!",
                explanation: "Other fields remained untouched."
            }
        ]
    },
    {
        id: 17,
        title: "Bulk Operations",
        description: "Batch processing.",
        points: 1300,
        instruction: "Creating multiple resources in one go.",
        tutorialContent: {
            title: "Batch Processing for Efficiency",
            text: "Instead of making 100 separate POST requests to create 100 users, send one batch request with all data. Benefits:\n\n• Reduces network round trips (1 vs 100 requests)\n• Faster processing\n• Lower server load\n• Can be atomic (all succeed or all fail)\n\nCommon patterns: /api/resources/batch or /api/resources with array body.",
            example: "Batch Creation:\n\nInstead of:\nPOST /api/users {\"name\":\"Alice\"}\nPOST /api/users {\"name\":\"Bob\"}\nPOST /api/users {\"name\":\"Carol\"}\n\nDo this:\nPOST /api/users/batch\nBody: [\n  {\"name\":\"Alice\"},\n  {\"name\":\"Bob\"},\n  {\"name\":\"Carol\"}\n]\n\nResponse:\n{ created: 3, ids: [1, 2, 3] }",
            keyPoints: [
                "Reduces network round trips dramatically",
                "Send array of objects in request body",
                "Consider: atomic (all-or-nothing) vs partial success",
                "Return summary of created/failed items"
            ],
            walkthrough: [
                {
                    title: "Create Multiple Users",
                    text: "You'll create two users in a single batch request instead of making two separate calls."
                },
                {
                    title: "Send Array Body",
                    text: "Method: POST, Endpoint: /api/users/batch, Body: [{\"name\":\"A\"},{\"name\":\"B\"}]. Both users created at once."
                }
            ]
        },
        subTasks: [
            {
                id: 't1',
                method: 'POST',
                endpoint: '/api/users/batch',
                body: '[{"name":"A"},{"name":"B"}]',
                description: '1. POST: Create two users at once.',
                hint: 'Body: Array of objects',
                expectedResponse: { created: 2 },
                successMessage: "Batch processed!",
                explanation: "Multiple resources created."
            }
        ]
    },
    {
        id: 18,
        title: "Asynchronous Operations",
        description: "Long running tasks.",
        points: 1350,
        instruction: "Return 202 Accepted for slow jobs.",
        tutorialContent: {
            title: "Handling Long-Running Tasks",
            text: "Some operations take minutes or hours (video processing, report generation, bulk imports). Don't keep the client waiting! Use asynchronous pattern:\n\n1. Accept the request immediately\n2. Return 202 Accepted status\n3. Provide a job/status URL\n4. Client polls the URL to check progress\n5. When done, status URL shows result\n\nThis prevents timeouts and improves user experience.",
            example: "Async Pattern:\n\n1. Start Job:\nPOST /api/video/process\nResponse: 202 Accepted\n{\n  \"status\": \"queued\",\n  \"job_id\": \"123\",\n  \"status_url\": \"/api/jobs/123\"\n}\n\n2. Check Status:\nGET /api/jobs/123\nResponse: 200 OK\n{ \"status\": \"processing\", \"progress\": 45 }\n\n3. Get Result:\nGET /api/jobs/123\nResponse: 200 OK\n{ \"status\": \"completed\", \"result_url\": \"/api/videos/456\" }",
            keyPoints: [
                "Use 202 Accepted for long-running operations",
                "Return job ID and status URL immediately",
                "Client polls status URL to check progress",
                "Prevents timeouts and connection issues"
            ],
            walkthrough: [
                {
                    title: "Start Background Job",
                    text: "You'll start a video processing job that runs in the background."
                },
                {
                    title: "Get Job URL",
                    text: "Method: POST, Endpoint: /api/video/process. Server returns 202 Accepted with a job URL for status checking."
                }
            ]
        },
        subTasks: [
            {
                id: 't1',
                method: 'POST',
                endpoint: '/api/video/process',
                description: '1. POST: Start video processing.',
                hint: 'POST /api/video/process',
                expectedResponse: { status: "queued", job_url: "/api/jobs/99" },
                successMessage: "202 Accepted!",
                explanation: "Job queued for background processing."
            }
        ]
    },

    // --- MODULE 5: ERROR HANDLING ---
    {
        id: 19,
        title: "Standard Error Responses",
        description: "RFC 7807 Problem Details.",
        points: 1400,
        instruction: "Use a standard format for errors.",
        tutorialContent: {
            title: "Standardized Error Format",
            text: "RFC 7807 defines a standard format for API errors. Instead of custom error formats, use Problem Details:\n\n• type - URL identifying the error type\n• title - Human-readable summary\n• status - HTTP status code\n• detail - Specific explanation\n• instance - URL to this specific error occurrence\n\nStandardization makes errors machine-readable and consistent.",
            example: "Standard Error Format:\n\n{\n  \"type\": \"https://api.com/errors/not-found\",\n  \"title\": \"Resource Not Found\",\n  \"status\": 404,\n  \"detail\": \"User with ID 123 does not exist\",\n  \"instance\": \"/api/users/123\"\n}\n\nvs Non-standard:\n{ \"error\": \"not found\" }",
            keyPoints: [
                "RFC 7807 provides standard error structure",
                "Machine-readable and consistent across API",
                "Include helpful details for debugging",
                "type field helps clients handle specific errors"
            ],
            walkthrough: [
                {
                    title: "Trigger Standard Error",
                    text: "You'll request a resource that doesn't exist and receive a standardized RFC 7807 error response."
                },
                {
                    title: "Check Error Format",
                    text: "Method: GET, Endpoint: /api/error-test. Response will follow RFC 7807 standard with type, title, status fields."
                }
            ]
        },
        subTasks: [
            {
                id: 't1',
                method: 'GET',
                endpoint: '/api/error-test',
                description: '1. GET: Trigger a standard error.',
                hint: 'URL: /api/error-test',
                expectedResponse: { type: "about:blank", title: "Not Found", status: 404 },
                successMessage: "Standard Error!",
                explanation: "Response followed RFC 7807."
            }
        ]
    },
    {
        id: 20,
        title: "Validation Errors",
        description: "422 Unprocessable Entity.",
        points: 1450,
        instruction: "Detailed field-level errors.",
        tutorialContent: {
            title: "Helpful Validation Messages",
            text: "When input fails validation, return 422 Unprocessable Entity with detailed, field-level error information:\n\n• Which field failed\n• What the problem is\n• How to fix it\n\nDon't just return 'Error' - be specific! This helps developers debug and users fix their input.",
            example: "Good Validation Response (422):\n{\n  \"errors\": [\n    {\n      \"field\": \"email\",\n      \"message\": \"Must be valid email format\"\n    },\n    {\n      \"field\": \"age\",\n      \"message\": \"Must be between 0 and 120\"\n    }\n  ]\n}\n\nBad Response:\n{ \"error\": \"Invalid input\" }",
            keyPoints: [
                "Use 422 status for validation failures",
                "List all validation errors, not just the first one",
                "Include field name and clear error message",
                "Help users fix problems, don't just reject"
            ],
            walkthrough: [
                {
                    title: "Send Invalid Data",
                    text: "You'll send a signup request with invalid age to trigger validation errors."
                },
                {
                    title: "Check Validation Response",
                    text: "Method: POST, Endpoint: /api/signup, Body: {\"age\":-5}. Server returns 422 with detailed error."
                }
            ]
        },
        subTasks: [
            {
                id: 't1',
                method: 'POST',
                endpoint: '/api/signup',
                body: '{"age":-5}',
                description: '1. POST: Send invalid age.',
                hint: 'Age cannot be negative',
                expectedResponse: { errors: [{ field: "age", message: "Must be positive" }] },
                successMessage: "Validation caught!",
                explanation: "422 returned with details."
            }
        ]
    },
    {
        id: 21,
        title: "Client vs Server Errors",
        description: "4xx vs 5xx.",
        points: 1500,
        instruction: "Know who is to blame.",
        tutorialContent: {
            title: "Error Responsibility",
            text: "HTTP status codes clearly indicate who should fix the problem:\n\n4xx Client Errors (400-499):\n• Client's fault (bad request, auth failure, etc)\n• Retrying without changes won't help\n• Client must fix their request\n\n5xx Server Errors (500-599):\n• Server's fault (bugs, crashes, timeouts)\n• Client can retry - might work later\n• Server team must investigate\n\nNever return 500 for bad input - that's a 400!",
            example: "Status Code Categories:\n\n4xx - Client Errors:\n400 Bad Request - Malformed syntax\n401 Unauthorized - Missing/invalid auth\n403 Forbidden - No permission\n404 Not Found - Resource doesn't exist\n422 Unprocessable - Validation failed\n\n5xx - Server Errors:\n500 Internal Server Error - Bug/crash\n502 Bad Gateway - Upstream failure\n503 Service Unavailable - Overloaded\n504 Gateway Timeout - Took too long",
            keyPoints: [
                "4xx = client must fix request before retrying",
                "5xx = server problem, client can retry later",
                "Never use 500 for validation or bad input",
                "Monitor 5xx rates - these are YOUR bugs"
            ],
            walkthrough: [
                {
                    title: "Trigger Client Error",
                    text: "You'll send a malformed request that triggers a 400-level client error."
                },
                {
                    title: "Understand the Difference",
                    text: "Method: GET, Endpoint: /api/bad-input. Returns 400 (client error), not 500 (server error)."
                }
            ]
        },
        subTasks: [
            {
                id: 't1',
                method: 'GET',
                endpoint: '/api/bad-input',
                description: '1. GET: Trigger client error.',
                hint: 'Expect 400',
                expectedResponse: { error: "Bad Request" },
                successMessage: "Client Error!",
                explanation: "Correctly identified as client fault."
            }
        ]
    },

    // --- MODULE 6: HATEOAS ---
    {
        id: 22,
        title: "HATEOAS Basics",
        description: "Hypermedia as the Engine of Application State.",
        points: 1550,
        instruction: "Include links in responses.",
        tutorialContent: {
            title: "Links",
            text: "_links: { self: { href: '...' } }",
            example: "Navigable API",
            keyPoints: [
                "Decouples client from URLs",
                "Discoverability"
            ]
        },
        subTasks: [
            {
                id: 't1',
                method: 'GET',
                endpoint: '/api/root',
                description: '1. GET: Fetch API root with links.',
                hint: 'URL: /api/root',
                expectedResponse: { _links: { users: { href: "/api/users" } } },
                successMessage: "Linked!",
                explanation: "Response contained navigation links."
            }
        ]
    },
    {
        id: 23,
        title: "Link Relations",
        description: "Meaning of links.",
        points: 1600,
        instruction: "rel='next', rel='prev', rel='edit'.",
        tutorialContent: {
            title: "Relationships",
            text: "Standard rel types help clients understand what links do.",
            example: "Pagination links",
            keyPoints: [
                "IANA registry of link relations",
                "Standardization"
            ]
        },
        subTasks: [
            {
                id: 't1',
                method: 'GET',
                endpoint: '/api/list?page=1',
                description: '1. GET: Check pagination links.',
                hint: 'Look for next link',
                expectedResponse: { _links: { next: { href: "/api/list?page=2" } } },
                successMessage: "Next page found!",
                explanation: "Link relation 'next' used correctly."
            }
        ]
    },
    {
        id: 24,
        title: "Discoverability",
        description: "Browsing the API.",
        points: 1650,
        instruction: "Clients should be able to navigate without hardcoding URLs.",
        tutorialContent: {
            title: "Follow the White Rabbit",
            text: "Start at root, follow links.",
            example: "Root -> Users -> User -> Orders",
            keyPoints: [
                "API can change URLs without breaking clients",
                "True REST"
            ]
        },
        subTasks: [
            {
                id: 't1',
                method: 'GET',
                endpoint: '/api/menu',
                description: '1. GET: Discover available actions.',
                hint: 'URL: /api/menu',
                expectedResponse: { actions: ["search", "login"] },
                successMessage: "Discovered!",
                explanation: "API revealed capabilities."
            }
        ]
    },

    // --- MODULE 7: SECURITY & RELIABILITY ---
    {
        id: 25,
        title: "Authentication",
        description: "Securing the API.",
        points: 1700,
        instruction: "Bearer tokens are standard.",
        tutorialContent: {
            title: "Who are you?",
            text: "Authorization: Bearer <token>",
            example: "Stateless auth",
            keyPoints: [
                "Don't use cookies for APIs (usually)",
                "Tokens are flexible"
            ]
        },
        subTasks: [
            {
                id: 't1',
                method: 'GET',
                endpoint: '/api/profile',
                headers: '{"Authorization":"Bearer xyz"}',
                description: '1. GET: Access profile with token.',
                hint: 'Header: Authorization',
                expectedResponse: { user: "me" },
                successMessage: "Authenticated!",
                explanation: "Token accepted."
            }
        ]
    },
    {
        id: 26,
        title: "Authorization",
        description: "Permissions.",
        points: 1750,
        instruction: "Scopes and Roles.",
        tutorialContent: {
            title: "Can you do this?",
            text: "403 Forbidden if token is valid but permission denied.",
            example: "Read-only token trying to POST",
            keyPoints: [
                "Granular permissions",
                "Least privilege"
            ]
        },
        subTasks: [
            {
                id: 't1',
                method: 'DELETE',
                endpoint: '/api/admin/users',
                headers: '{"Authorization":"Bearer user_token"}',
                description: '1. DELETE: Try admin action as user.',
                hint: 'Expect 403',
                expectedResponse: { error: "Forbidden" },
                successMessage: "Access Denied!",
                explanation: "Correctly blocked unauthorized action."
            }
        ]
    },
    {
        id: 27,
        title: "Rate Limiting",
        description: "Protecting resources.",
        points: 1800,
        instruction: "Headers and 429 status.",
        tutorialContent: {
            title: "Slow Down",
            text: "X-RateLimit-Limit, X-RateLimit-Remaining",
            example: "429 Too Many Requests",
            keyPoints: [
                "Prevent abuse",
                "Fair usage"
            ]
        },
        subTasks: [
            {
                id: 't1',
                method: 'GET',
                endpoint: '/api/high-freq',
                description: '1. GET: Check rate limit headers.',
                hint: 'URL: /api/high-freq',
                expectedResponse: { headers: { "X-RateLimit-Remaining": "0" } },
                successMessage: "Limit checked!",
                explanation: "Rate limit headers present."
            }
        ]
    },
    {
        id: 28,
        title: "Caching in REST",
        description: "Performance.",
        points: 1850,
        instruction: "ETags and Conditional Requests.",
        tutorialContent: {
            title: "If-None-Match",
            text: "Client sends ETag, server returns 304 if match.",
            example: "Efficient updates",
            keyPoints: [
                "Saves bandwidth",
                "Lowers latency"
            ]
        },
        subTasks: [
            {
                id: 't1',
                method: 'GET',
                endpoint: '/api/resource',
                headers: '{"If-None-Match":"v1"}',
                description: '1. GET: Conditional get.',
                hint: 'Header: If-None-Match',
                expectedResponse: null, // 304
                successMessage: "304 Not Modified!",
                explanation: "Resource hasn't changed."
            }
        ]
    },
    {
        id: 29,
        title: "Versioning Strategies",
        description: "Managing change.",
        points: 1900,
        instruction: "URL vs Header versioning.",
        tutorialContent: {
            title: "Evolution",
            text: "/v1/users vs Accept: application/vnd.myapi.v1+json",
            example: "Breaking changes require new version",
            keyPoints: [
                "Don't break existing clients",
                "Plan for evolution"
            ]
        },
        subTasks: [
            {
                id: 't1',
                method: 'GET',
                endpoint: '/api/v2/features',
                description: '1. GET: Access v2 API.',
                hint: 'URL: /api/v2/features',
                expectedResponse: { features: ["new"] },
                successMessage: "V2 Accessed!",
                explanation: "Versioned endpoint accessed."
            }
        ]
    },

    // --- MODULE 8: FINAL PROJECT ---
    {
        id: 30,
        title: "API Architect Exam",
        description: "The ultimate test.",
        points: 2500,
        instruction: "Design and interact with a complex system.",
        tutorialContent: {
            title: "Final Challenge",
            text: "1. Auth\n2. Create\n3. Verify\n4. Cleanup",
            example: "Good luck!",
            keyPoints: [
                "Synthesis of all skills"
            ]
        },
        subTasks: [
            {
                id: 't1',
                method: 'POST',
                endpoint: '/api/auth',
                body: '{"user":"architect"}',
                description: '1. Auth: Get token.',
                hint: 'POST /api/auth',
                expectedResponse: { token: "arch_token" },
                successMessage: "Token Acquired!",
                explanation: "Step 1 complete."
            },
            {
                id: 't2',
                method: 'POST',
                endpoint: '/api/blueprints',
                headers: '{"Authorization":"Bearer arch_token"}',
                body: '{"name":"Skyscraper"}',
                description: '2. Create: Submit blueprint.',
                hint: 'Use token',
                expectedResponse: { id: 101, status: "pending" },
                successMessage: "Blueprint Created!",
                explanation: "Step 2 complete."
            },
            {
                id: 't3',
                method: 'GET',
                endpoint: '/api/blueprints/101',
                headers: '{"Authorization":"Bearer arch_token"}',
                description: '3. Verify: Check status.',
                hint: 'GET /api/blueprints/101',
                expectedResponse: { id: 101, status: "approved" },
                successMessage: "Approved!",
                explanation: "Step 3 complete."
            },
            {
                id: 't4',
                method: 'DELETE',
                endpoint: '/api/blueprints/101',
                headers: '{"Authorization":"Bearer arch_token"}',
                description: '4. Cleanup: Archive blueprint.',
                hint: 'DELETE',
                expectedResponse: {},
                successMessage: "Archived!",
                explanation: "Exam Passed. You are a REST Architect."
            }
        ]
    }
];
