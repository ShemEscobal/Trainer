export const levels = [
    // --- MODULE 1: THE BASICS ---
    {
        id: 1,
        title: "HTTP Methods Bootcamp",
        description: "Master the four fundamental HTTP methods: GET, POST, PUT, and DELETE.",
        points: 500,
        instruction: "To communicate effectively with servers, you need to know the CRUD operations.",
        tutorialContent: {
            title: "The 4 Pillars of HTTP",
            text: "Most web applications are built around 4 key actions, often called CRUD. In HTTP, these map to specific methods:\n\n1. GET (Read): Ask for data.\n2. POST (Create): Send data to make something new.\n3. PUT (Update): Send data to change something.\n4. DELETE (Delete): Remove something.",
            example: "GET /api/users (List users)\nPOST /api/users (Add user)\nPUT /api/users/1 (Edit user #1)\nDELETE /api/users/1 (Remove user #1)",
            keyPoints: [
                "GET: Retrieve data (Safe, doesn't change anything).",
                "POST: Create new resources.",
                "PUT: Update existing resources.",
                "DELETE: Remove resources."
            ],
            walkthrough: [
                { title: "1. GET Request", text: "Select GET. URL: /api/bootcamp. Click Send." },
                { title: "2. POST Request", text: "Select POST. URL: /api/bootcamp. Body: {\"status\": \"ready\"}. Click Send." },
                { title: "3. PUT Request", text: "Select PUT. URL: /api/bootcamp/101. Body: {\"status\": \"training\"}. Click Send." },
                { title: "4. DELETE Request", text: "Select DELETE. URL: /api/bootcamp/101. Click Send." }
            ]
        },
        subTasks: [
            {
                id: 't1',
                method: 'GET',
                endpoint: '/api/bootcamp',
                description: '1. GET: Retrieve the welcome message.',
                hint: 'URL: /api/bootcamp',
                expectedResponse: { message: "Welcome to Bootcamp!" },
                successMessage: "Great start!",
                explanation: "You successfully sent a GET request to retrieve data from the server."
            },
            {
                id: 't2',
                method: 'POST',
                endpoint: '/api/bootcamp',
                body: '{"status":"ready"}',
                description: '2. POST: Send your status as "ready".',
                hint: 'Body: {"status": "ready"}',
                expectedResponse: { status: "ready", id: 101 },
                successMessage: "Awesome!",
                explanation: "You used POST to create a new resource on the server with a JSON body."
            },
            {
                id: 't3',
                method: 'PUT',
                endpoint: '/api/bootcamp/101',
                body: '{"status":"training"}',
                description: '3. PUT: Update your status to "training".',
                hint: 'URL: .../101 | Body: {"status": "training"}',
                expectedResponse: { status: "training", id: 101 },
                successMessage: "Nice update!",
                explanation: "You used PUT to update an existing resource. Notice how the status changed."
            },
            {
                id: 't4',
                method: 'DELETE',
                endpoint: '/api/bootcamp/101',
                description: '4. DELETE: Remove your record to finish.',
                hint: 'URL: /api/bootcamp/101',
                expectedResponse: null,
                successMessage: "Mission Complete!",
                explanation: "You used DELETE to remove the resource. You've mastered the basics!"
            }
        ]
    },
    {
        id: 2,
        title: "Query Parameters",
        description: "Learn how to filter data using query parameters in the URL.",
        points: 150,
        instruction: "Query parameters are key-value pairs added to the end of a URL, starting with a '?' and separated by '&'.",
        tutorialContent: {
            title: "Anatomy of a Query",
            text: "Query parameters allow you to be specific about what you want. They are added to the end of the URL path.",
            example: "GET /api/search?q=shoes&sort=price",
            keyPoints: [
                "The '?' marks the end of the path and start of parameters.",
                "Each parameter is a 'key=value' pair.",
                "Use '&' to add as many parameters as you need."
            ]
        },
        subTasks: [
            {
                id: 'l2t1',
                method: 'GET',
                endpoint: '/api/search?q=http',
                description: "1. Filter: Search for 'http' using a query parameter.",
                hint: "URL: /api/search?q=http",
                expectedResponse: { results: ["HTTP Basics", "HTTP Methods"] },
                successMessage: "Filter Master!",
                explanation: "You successfully used query parameters to filter the search results."
            }
        ]
    },
    {
        id: 3,
        title: "Request Body",
        description: "Learn how to send structured data to the server.",
        points: 200,
        instruction: "The body contains the actual data you want to send, usually in JSON format.",
        tutorialContent: {
            title: "The Request Body",
            text: "While the URL tells the server *where* to send data, the Body contains the *actual data*. This keeps URLs clean and secure.",
            example: "POST /api/users\nBody: {\"name\": \"Alice\", \"email\": \"alice@example.com\"}",
            keyPoints: [
                "URL is just the destination address.",
                "Data lives in the 'Body', hidden from the URL bar.",
                "JSON format uses { curly braces } and \"quotes\"."
            ]
        },
        subTasks: [
            {
                id: 'l3t1',
                method: 'POST',
                endpoint: '/api/users',
                body: '{"name":"Alice"}',
                description: "1. Create: Send a POST request to create a user.",
                hint: 'Body: {"name": "Alice"}',
                expectedResponse: { id: 123, status: "created" },
                successMessage: "Resource Created!",
                explanation: "You successfully sent data in the body to create a new user."
            }
        ]
    },
    {
        id: 4,
        title: "Response Anatomy",
        description: "Understand what comes back from the server.",
        points: 250,
        instruction: "A response consists of a Status Line, Headers, and an optional Body.",
        tutorialContent: {
            title: "Reading Responses",
            text: "Every response has three parts:\n1. Status Line: 200 OK\n2. Headers: Content-Type: application/json\n3. Body: The actual data requested.",
            example: "HTTP/1.1 200 OK\nContent-Type: application/json\n\n{\"message\": \"Hello\"}",
            keyPoints: [
                "Status code tells you if it worked.",
                "Headers give context.",
                "Body contains the content."
            ]
        },
        subTasks: [
            {
                id: 'l4t1',
                method: 'GET',
                endpoint: '/api/anatomy',
                description: "1. Inspect: Send a request and observe the response parts.",
                hint: "URL: /api/anatomy",
                expectedResponse: { status: "OK", headers: "present", body: "valid" },
                successMessage: "Anatomy Lesson Complete!",
                explanation: "You've seen the three parts of an HTTP response."
            }
        ]
    },
    {
        id: 5,
        title: "Status Codes Intro",
        description: "Learn the language of server responses.",
        points: 300,
        instruction: "Status codes indicate the result of the HTTP request.",
        tutorialContent: {
            title: "The Server's Reply",
            text: "When you send a request to a URL, the server replies with a 3-digit code.",
            example: "200 OK (Success)\n404 Not Found (Client Error)\n500 Internal Server Error (Server Error)",
            keyPoints: [
                "2xx: Success",
                "4xx: Client Error (Your fault)",
                "5xx: Server Error (Their fault)"
            ]
        },
        subTasks: [
            {
                id: 'l5t1',
                method: 'GET',
                endpoint: '/api/missing',
                description: "1. Trigger 404: Try to access a missing page.",
                hint: "URL: /api/missing",
                expectedResponse: { error: "Not Found" },
                successMessage: "404 Found!",
                explanation: "You successfully triggered a 404 Not Found error."
            }
        ]
    },

    // --- MODULE 2: ADVANCED METHODS ---
    {
        id: 6,
        title: "PATCH vs PUT",
        description: "Understand the difference between partial and full updates.",
        points: 350,
        instruction: "PUT replaces the entire resource. PATCH updates only specified fields.",
        tutorialContent: {
            title: "Surgical Updates",
            text: "PUT is like replacing a file. PATCH is like editing a line in the file.",
            example: "PUT /users/1 {name: 'Bob', age: 30} (Needs all fields)\nPATCH /users/1 {age: 31} (Only updates age)",
            keyPoints: [
                "PUT = Replace completely",
                "PATCH = Modify partially",
                "PATCH is more bandwidth efficient"
            ]
        },
        subTasks: [
            {
                id: 'l6t1',
                method: 'PATCH',
                endpoint: '/api/users/1',
                body: '{"email":"new@email.com"}',
                description: "1. Update Email: Use PATCH to change only the email.",
                hint: "Method: PATCH | Body: {'email': '...'}",
                expectedResponse: { id: 1, name: "Original", email: "new@email.com" },
                successMessage: "Patched!",
                explanation: "You updated just the email without sending the whole user object."
            }
        ]
    },
    {
        id: 7,
        title: "HEAD Method",
        description: "Retrieve headers without the body.",
        points: 400,
        instruction: "HEAD is identical to GET, but the server returns NO body. Useful for checking if a resource exists or its size.",
        tutorialContent: {
            title: "Just the Headers",
            text: "Use HEAD to check file size (Content-Length) or existence without downloading the whole thing.",
            example: "HEAD /large-video.mp4",
            keyPoints: [
                "Same headers as GET",
                "No body returned",
                "Fast and efficient for checks"
            ]
        },
        subTasks: [
            {
                id: 'l7t1',
                method: 'HEAD',
                endpoint: '/api/large-file',
                description: "1. Check Size: Use HEAD to check a file's metadata.",
                hint: "Method: HEAD",
                expectedResponse: null,
                successMessage: "Heads up!",
                explanation: "You got the headers without downloading the file body."
            }
        ]
    },
    {
        id: 8,
        title: "OPTIONS Method",
        description: "Discover allowed methods for a resource.",
        points: 450,
        instruction: "OPTIONS asks the server: 'What methods can I use on this URL?'",
        tutorialContent: {
            title: "Permission Check",
            text: "Browsers use OPTIONS for CORS preflight checks to see if it's safe to send a request.",
            example: "OPTIONS /api/users\nResponse: Allow: GET, POST, OPTIONS",
            keyPoints: [
                "Returns 'Allow' header",
                "Used for CORS",
                "Safe method"
            ]
        },
        subTasks: [
            {
                id: 'l8t1',
                method: 'OPTIONS',
                endpoint: '/api/users',
                description: "1. Discovery: Check allowed methods for /api/users.",
                hint: "Method: OPTIONS",
                expectedResponse: null,
                successMessage: "Options Revealed!",
                explanation: "The server responded with the Allow header listing valid methods."
            }
        ]
    },

    // --- MODULE 3: STATUS CODES DEEP DIVE ---
    {
        id: 9,
        title: "Redirection (3xx)",
        description: "Handling moved resources.",
        points: 500,
        instruction: "301 means 'Moved Permanently'. 302 means 'Found' (Moved Temporarily).",
        tutorialContent: {
            title: "Please Forward",
            text: "When a URL changes, the server sends a 3xx code and a 'Location' header pointing to the new URL.",
            example: "301 Moved Permanently\nLocation: /new-page",
            keyPoints: [
                "301: Permanent (Update bookmarks)",
                "302: Temporary (Don't update bookmarks)",
                "Location header tells where to go"
            ]
        },
        subTasks: [
            {
                id: 'l9t1',
                method: 'GET',
                endpoint: '/api/old-page',
                description: "1. Follow Redirect: Request a moved page.",
                hint: "URL: /api/old-page",
                expectedResponse: { message: "You have been redirected to /api/new-page" },
                successMessage: "Redirected!",
                explanation: "The server sent a 301 and your client followed it to the new location."
            }
        ]
    },
    {
        id: 10,
        title: "Client Errors I (400, 422)",
        description: "Bad requests and invalid data.",
        points: 550,
        instruction: "400 Bad Request is generic. 422 Unprocessable Entity is for validation errors.",
        tutorialContent: {
            title: "It's Not Me, It's You",
            text: "4xx errors mean the client sent something wrong.\n400: Malformed syntax.\n422: Valid syntax, but semantic errors (e.g., password too short).",
            example: "POST /login (missing body) -> 400\nPOST /login (password='123') -> 422",
            keyPoints: [
                "400: Syntax error",
                "422: Validation error",
                "Fix the request and try again"
            ]
        },
        subTasks: [
            {
                id: 'l10t1',
                method: 'POST',
                endpoint: '/api/register',
                body: '{"pass":"1"}',
                description: "1. Trigger 422: Send a password that is too short.",
                hint: "Body: {'pass': '1'}",
                expectedResponse: { error: "Password too short" },
                successMessage: "Validation Caught!",
                explanation: "The server rejected the data with a 422 Unprocessable Entity."
            }
        ]
    },
    {
        id: 11,
        title: "Client Errors II (401 vs 403)",
        description: "Authentication vs Authorization.",
        points: 600,
        instruction: "401 Unauthorized means 'Who are you?'. 403 Forbidden means 'You can't go here'.",
        tutorialContent: {
            title: "ID vs Clearance",
            text: "401: You didn't provide a valid ID (Login).\n403: You have an ID, but you don't have permission (Admin only).",
            example: "401: Please login.\n403: Admins only.",
            keyPoints: [
                "401: Unauthenticated",
                "403: Unauthorized",
                "401 can be fixed by logging in"
            ]
        },
        subTasks: [
            {
                id: 'l11t1',
                method: 'GET',
                endpoint: '/api/admin',
                description: "1. Trigger 403: Try to access admin area as a guest.",
                hint: "URL: /api/admin",
                expectedResponse: { error: "Forbidden" },
                successMessage: "Access Denied!",
                explanation: "You received a 403 because you lack admin privileges."
            }
        ]
    },
    {
        id: 12,
        title: "Server Errors (5xx)",
        description: "When the server fails.",
        points: 650,
        instruction: "500 Internal Server Error is a generic crash. 503 Service Unavailable means overloaded or maintenance.",
        tutorialContent: {
            title: "It's Not You, It's Me",
            text: "5xx errors mean the server crashed or is down. Retrying might work later.",
            example: "500: NullPointerException in code.\n503: Server is restarting.",
            keyPoints: [
                "500: Generic crash",
                "502: Bad Gateway (Upstream error)",
                "503: Maintenance/Overload"
            ]
        },
        subTasks: [
            {
                id: 'l12t1',
                method: 'GET',
                endpoint: '/api/crash',
                description: "1. Trigger 500: Call a buggy endpoint.",
                hint: "URL: /api/crash",
                expectedResponse: { error: "Internal Server Error" },
                successMessage: "Server Crashed!",
                explanation: "The server encountered an unhandled exception."
            }
        ]
    },

    // --- MODULE 4: HEADERS MASTERY ---
    {
        id: 13,
        title: "Content Negotiation",
        description: "Asking for the right format.",
        points: 700,
        instruction: "Use the 'Accept' header to tell the server what format you want (JSON, XML, HTML).",
        tutorialContent: {
            title: "Speaking the Same Language",
            text: "Clients use 'Accept' to request formats. Servers use 'Content-Type' to say what they sent.",
            example: "Accept: application/json\nAccept: application/xml",
            keyPoints: [
                "Accept: What I want",
                "Content-Type: What this is",
                "406 Not Acceptable: Server can't provide that format"
            ]
        },
        subTasks: [
            {
                id: 'l13t1',
                method: 'GET',
                endpoint: '/api/data',
                headers: '{"Accept":"application/xml"}',
                description: "1. Request XML: Ask for data in XML format.",
                hint: "Header: Accept: application/xml",
                expectedResponse: { format: "xml" },
                successMessage: "XML Received!",
                explanation: "The server respected your Accept header."
            }
        ]
    },
    {
        id: 14,
        title: "Caching Basics",
        description: "Speeding up the web.",
        points: 750,
        instruction: "Cache-Control headers tell browsers how long to save a file.",
        tutorialContent: {
            title: "Don't Download Twice",
            text: "Cache-Control: max-age=3600 means 'Don't ask again for 1 hour'.",
            example: "Cache-Control: no-cache (Always check)\nCache-Control: public, max-age=86400",
            keyPoints: [
                "max-age: Seconds to cache",
                "no-store: Never cache",
                "private: Only cache for this user"
            ]
        },
        subTasks: [
            {
                id: 'l14t1',
                method: 'GET',
                endpoint: '/api/static/image.png',
                description: "1. Check Cache: Get a static asset.",
                hint: "URL: /api/static/image.png",
                expectedResponse: { cached: true },
                successMessage: "Cached!",
                explanation: "The response included Cache-Control headers."
            }
        ]
    },
    {
        id: 15,
        title: "Advanced Caching (ETags)",
        description: "Conditional requests.",
        points: 800,
        instruction: "ETags are like fingerprints for files. If the fingerprint matches, the server sends 304 Not Modified.",
        tutorialContent: {
            title: "Has It Changed?",
            text: "1. Server sends ETag: 'abc'.\n2. Client sends If-None-Match: 'abc'.\n3. Server sends 304 (Empty body) if match.",
            example: "If-None-Match: \"v1.0\"",
            keyPoints: [
                "Saves bandwidth",
                "304 has no body",
                "ETag is the version ID"
            ]
        },
        subTasks: [
            {
                id: 'l15t1',
                method: 'GET',
                endpoint: '/api/file',
                headers: '{"If-None-Match":"12345"}',
                description: "1. Conditional Get: Check if file '12345' has changed.",
                hint: "Header: If-None-Match: 12345",
                expectedResponse: null, // 304
                successMessage: "304 Not Modified!",
                explanation: "The server confirmed your version is up to date."
            }
        ]
    },
    {
        id: 16,
        title: "Cookies & State",
        description: "Remembering users.",
        points: 850,
        instruction: "HTTP is stateless. Cookies allow servers to remember you between requests.",
        tutorialContent: {
            title: "The Cookie Jar",
            text: "Server sends 'Set-Cookie'. Browser sends 'Cookie' on next request.",
            example: "Set-Cookie: session_id=xyz; Secure; HttpOnly",
            keyPoints: [
                "HttpOnly: JS can't read it (Security)",
                "Secure: HTTPS only",
                "Used for sessions"
            ]
        },
        subTasks: [
            {
                id: 'l16t1',
                method: 'GET',
                endpoint: '/api/login',
                description: "1. Get Cookie: Simulate a login to receive a cookie.",
                hint: "URL: /api/login",
                expectedResponse: { cookie: "session=123" },
                successMessage: "Cookie Set!",
                explanation: "The server sent a Set-Cookie header."
            }
        ]
    },

    // --- MODULE 5: SECURITY & AUTHENTICATION ---
    {
        id: 17,
        title: "Basic Authentication",
        description: "The oldest auth method.",
        points: 900,
        instruction: "Sends 'username:password' encoded in Base64. Only safe over HTTPS.",
        tutorialContent: {
            title: "Simple but Risky",
            text: "Authorization: Basic <base64_string>.",
            example: "Authorization: Basic dXNlcjpwYXNz",
            keyPoints: [
                "Easily decoded",
                "Must use HTTPS",
                "Stateless"
            ]
        },
        subTasks: [
            {
                id: 'l17t1',
                method: 'GET',
                endpoint: '/api/basic-protected',
                headers: '{"Authorization":"Basic dXNlcjpwYXNz"}',
                description: "1. Basic Auth: Access protected route.",
                hint: "Header: Authorization: Basic dXNlcjpwYXNz",
                expectedResponse: { access: "granted" },
                successMessage: "Authenticated!",
                explanation: "You provided valid Basic credentials."
            }
        ]
    },
    {
        id: 18,
        title: "Bearer Tokens (JWT)",
        description: "Modern API authentication.",
        points: 950,
        instruction: "Uses 'Authorization: Bearer <token>'. Tokens are often JWTs (JSON Web Tokens).",
        tutorialContent: {
            title: "The Access Pass",
            text: "You login once, get a token, and show it everywhere.",
            example: "Authorization: Bearer eyJhbG...",
            keyPoints: [
                "Token is self-contained",
                "Server doesn't store session",
                "Expires after time"
            ]
        },
        subTasks: [
            {
                id: 'l18t1',
                method: 'GET',
                endpoint: '/api/dashboard',
                headers: '{"Authorization":"Bearer my.jwt.token"}',
                description: "1. Bearer Auth: Access dashboard with a token.",
                hint: "Header: Authorization: Bearer my.jwt.token",
                expectedResponse: { data: "dashboard" },
                successMessage: "Token Accepted!",
                explanation: "You accessed a protected route using a Bearer token."
            }
        ]
    },
    {
        id: 19,
        title: "API Keys",
        description: "Machine-to-machine auth.",
        points: 1000,
        instruction: "API Keys identify the project or client, not necessarily the user.",
        tutorialContent: {
            title: "The Club Membership",
            text: "Usually sent in a custom header like 'X-API-Key'.",
            example: "X-API-Key: abc-123-xyz",
            keyPoints: [
                "Long-lived",
                "Keep them secret",
                "Used for rate limiting"
            ]
        },
        subTasks: [
            {
                id: 'l19t1',
                method: 'GET',
                endpoint: '/api/weather',
                headers: '{"X-API-Key":"weather_app_1"}',
                description: "1. API Key: Fetch weather data.",
                hint: "Header: X-API-Key: weather_app_1",
                expectedResponse: { temp: "25C" },
                successMessage: "Key Valid!",
                explanation: "The API key identified your application."
            }
        ]
    },
    {
        id: 20,
        title: "CORS",
        description: "Cross-Origin Resource Sharing.",
        points: 1050,
        instruction: "Browsers block requests to different domains unless CORS headers are present.",
        tutorialContent: {
            title: "The Bouncer",
            text: "Access-Control-Allow-Origin tells the browser which sites can read the response.",
            example: "Access-Control-Allow-Origin: * (Everyone)\nAccess-Control-Allow-Origin: https://myapp.com",
            keyPoints: [
                "Browser security feature",
                "Server must explicitly allow",
                "Preflight OPTIONS request checks this"
            ]
        },
        subTasks: [
            {
                id: 'l20t1',
                method: 'GET',
                endpoint: '/api/public-data',
                description: "1. CORS Check: Request data from another origin.",
                hint: "URL: /api/public-data",
                expectedResponse: { cors: "allowed" },
                successMessage: "CORS Allowed!",
                explanation: "The server sent the correct Access-Control-Allow-Origin header."
            }
        ]
    },

    // --- MODULE 6: PERFORMANCE & OPTIMIZATION ---
    {
        id: 21,
        title: "Compression",
        description: "Shrinking payloads.",
        points: 1100,
        instruction: "Accept-Encoding: gzip tells the server you can handle compressed data.",
        tutorialContent: {
            title: "Zipping It Up",
            text: "Text compresses very well (up to 90%). Always use compression for JSON/HTML.",
            example: "Accept-Encoding: gzip, deflate, br",
            keyPoints: [
                "Reduces bandwidth",
                "Faster loads",
                "Browser handles decompression automatically"
            ]
        },
        subTasks: [
            {
                id: 'l21t1',
                method: 'GET',
                endpoint: '/api/big-list',
                headers: '{"Accept-Encoding":"gzip"}',
                description: "1. Gzip: Request compressed data.",
                hint: "Header: Accept-Encoding: gzip",
                expectedResponse: { compressed: true },
                successMessage: "Compressed!",
                explanation: "The server returned gzipped content."
            }
        ]
    },
    {
        id: 22,
        title: "Connection Management",
        description: "Keep-Alive.",
        points: 1150,
        instruction: "Opening a TCP connection is slow. Keep-Alive reuses it.",
        tutorialContent: {
            title: "Stay on the Line",
            text: "Connection: keep-alive is default in HTTP/1.1.",
            example: "Connection: close (Hang up after this)",
            keyPoints: [
                "Reduces latency",
                "Less CPU usage",
                "Crucial for HTTPS (SSL handshake is expensive)"
            ]
        },
        subTasks: [
            {
                id: 'l22t1',
                method: 'GET',
                endpoint: '/api/stream',
                headers: '{"Connection":"keep-alive"}',
                description: "1. Keep-Alive: Request a persistent connection.",
                hint: "Header: Connection: keep-alive",
                expectedResponse: { connection: "kept" },
                successMessage: "Connected!",
                explanation: "Connection kept open for subsequent requests."
            }
        ]
    },
    {
        id: 23,
        title: "Rate Limiting",
        description: "Handling 429 Too Many Requests.",
        points: 1200,
        instruction: "APIs limit how fast you can call them. 429 means 'Slow Down'.",
        tutorialContent: {
            title: "Speed Limit",
            text: "Look for 'Retry-After' header to know when to come back.",
            example: "429 Too Many Requests\nRetry-After: 60 (seconds)",
            keyPoints: [
                "Respect limits",
                "Exponential backoff",
                "X-RateLimit-Remaining header"
            ]
        },
        subTasks: [
            {
                id: 'l23t1',
                method: 'GET',
                endpoint: '/api/spam',
                description: "1. Trigger 429: Send too many requests.",
                hint: "URL: /api/spam",
                expectedResponse: { error: "Too Many Requests" },
                successMessage: "Rate Limited!",
                explanation: "You hit the rate limit. The server said 'Stop'."
            }
        ]
    },

    // --- MODULE 7: FINAL EXAM ---
    {
        id: 24,
        title: "The Gauntlet",
        description: "Prove your HTTP mastery.",
        points: 2000,
        instruction: "Combine everything you've learned to complete this multi-step challenge.",
        tutorialContent: {
            title: "Final Challenge",
            text: "1. Login to get a token.\n2. Use token to create a resource.\n3. Update the resource.\n4. Delete it.",
            example: "Good luck!",
            keyPoints: [
                "Auth",
                "Methods",
                "Headers",
                "Status Codes"
            ]
        },
        subTasks: [
            {
                id: 'l24t1',
                method: 'POST',
                endpoint: '/api/login',
                body: '{"user":"admin"}',
                description: "1. Login: Get your auth token.",
                hint: "POST /api/login",
                expectedResponse: { token: "secret_token" },
                successMessage: "Logged In!",
                explanation: "Step 1 Complete. You have the token."
            },
            {
                id: 'l24t2',
                method: 'POST',
                endpoint: '/api/secure/items',
                headers: '{"Authorization":"Bearer secret_token"}',
                body: '{"name":"Artifact"}',
                description: "2. Create: Use token to create an item.",
                hint: "Auth Header + POST Body",
                expectedResponse: { id: 99, name: "Artifact" },
                successMessage: "Item Created!",
                explanation: "Step 2 Complete. Resource created securely."
            },
            {
                id: 'l24t3',
                method: 'DELETE',
                endpoint: '/api/secure/items/99',
                headers: '{"Authorization":"Bearer secret_token"}',
                description: "3. Cleanup: Delete the item.",
                hint: "Auth Header + DELETE",
                expectedResponse: null,
                successMessage: "Gauntlet Complete!",
                explanation: "Congratulations! You are an HTTP Master."
            }
        ]
    }
];
