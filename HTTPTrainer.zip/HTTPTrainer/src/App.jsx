import React, { useState, useEffect } from 'react';
import Dashboard from './components/Dashboard';
import Layout from './components/Layout';
import LevelGuide from './components/LevelGuide';
import RequestSimulator from './components/RequestSimulator';
import Certificate from './components/Certificate';
import TutorialView from './components/TutorialView';
import LevelRecap from './components/LevelRecap';
import RESTAPITrainer from './modules/RESTAPITrainer';
import { useGame } from './context/GameContext';
import { levels } from './data/levels';
import './App.css';

function App() {
  const { currentLevel, setCurrentLevel, completedLevels, nextLevel, points } = useGame();
  const [showTutorial, setShowTutorial] = useState(true);
  const [showRecap, setShowRecap] = useState(false);
  const [completedSubTasks, setCompletedSubTasks] = useState([]);
  const [currentView, setCurrentView] = useState('dashboard'); // dashboard or module
  const [selectedModule, setSelectedModule] = useState(null);
  const totalLevels = levels.length;

  const currentLevelData = levels.find(l => l.id === currentLevel);
  const isCompleted = completedLevels.length === totalLevels;

  // Show tutorial and reset subtasks whenever level changes
  useEffect(() => {
    setShowTutorial(true);
    setCompletedSubTasks([]);
  }, [currentLevel]);

  // Save module progress to localStorage
  useEffect(() => {
    if (selectedModule && selectedModule.id === 'http-protocol') {
      const progress = {
        completedLevels: completedLevels.length,
        totalLevels: totalLevels,
        points: points,
        lastAccessed: new Date().toISOString()
      };
      localStorage.setItem(`module_${selectedModule.id}_progress`, JSON.stringify(progress));
    }
  }, [completedLevels, points, selectedModule]);

  const handleSuccess = () => {
    setShowRecap(true);
  };

  const handleContinueFromRecap = () => {
    setShowRecap(false);
    nextLevel();
    setShowTutorial(true);
    setCompletedSubTasks([]);
  };

  const handleStartExercise = () => {
    setShowTutorial(false);
  };

  const handleToggleTutorial = () => {
    setShowTutorial(!showTutorial);
  };

  const handleSelectModule = (module) => {
    setSelectedModule(module);
    setCurrentView('module');
  };

  const handleBackToDashboard = () => {
    setCurrentView('dashboard');
    setSelectedModule(null);
  };

  // Dashboard view
  if (currentView === 'dashboard') {
    return <Dashboard onSelectModule={handleSelectModule} />;
  }

  // Render selected module
  if (selectedModule) {
    if (selectedModule.id === 'rest-api') {
      return <RESTAPITrainer onBackToDashboard={handleBackToDashboard} />;
    }
    // HTTP Protocol module (default)
    if (selectedModule.id === 'http-protocol') {
      // Existing HTTP Protocol trainer logic
      if (isCompleted) {
        return (
          <div className="app-layout">
            <Certificate
              userName="Congratulations!"
              courseName="HTTP Protocol Training"
              completionDate={new Date().toLocaleDateString()}
              totalPoints={points}
            />
          </div>
        );
      }

      return (
        <Layout
          currentLevel={currentLevel}
          completedLevels={completedLevels}
          totalLevels={totalLevels}
          points={points}
          onBackToDashboard={handleBackToDashboard}
          onLevelSelect={setCurrentLevel}
        >
          {showRecap ? (
            <LevelRecap
              level={currentLevelData}
              onNextLevel={handleContinueFromRecap}
            />
          ) : showTutorial ? (
            <TutorialView
              level={currentLevelData}
              onStartExercise={handleStartExercise}
            />
          ) : (
            <div className="level-container">
              <LevelGuide
                level={currentLevelData}
                subTaskStates={completedSubTasks}
                onToggleTutorial={handleToggleTutorial}
              />
              <RequestSimulator
                level={currentLevelData}
                onSuccess={handleSuccess}
                subTaskStates={completedSubTasks}
                setSubTaskStates={setCompletedSubTasks}
              />
            </div>
          )}
        </Layout>
      );
    }
  }

  return null;
}

export default App;
